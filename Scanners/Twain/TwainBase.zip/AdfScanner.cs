using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Threading;
using System.Collections.Generic;
using System.Runtime.InteropServices;


namespace Scanners.Twain
{
	public class AdfScanner : TwainBase, IDisposable, IScanner
	{
		//bool											isFeederLoaded = true;
		//System.Windows.Threading.DispatcherTimer		timer = new System.Windows.Threading.DispatcherTimer();

		//public delegate void FeederLoadedHnd();
		//public event Kic.Scanners.AdfScanner.FeederLoadedHnd		FeederLoaded;
		//public event Kic.Scanners.AdfScanner.FeederLoadedHnd		FeederUnloaded;
		public event TwainApp.TwainStateChangedHandler				TwainStateChanged;


		#region constructor
		/// <summary>
		/// must be called from main window thread!!!
		/// </summary>
		public AdfScanner(Scanners.ScannerType scannerType)
			: base()
		{
			if (scanner == null)
				Init(Scanners.Settings.Instance.AdfAddOnScanner.ScannerType);

			if (registeredCallers.Contains(this) == false)
				registeredCallers.Add(this);
		}
		#endregion


		#region enum AdfScannerType
		public enum AdfScannerType
		{
			Standalone,
			AddOnScanner
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties

		public static bool				Initialized		{ get { return (scanner != null); } }
		public TwainApp.TwainState		TwainState		{ get { return (scanner != null) ? scanner.State : TwainApp.TwainState.PreSession; } }

		#region IsFeederLoaded
		/*public bool IsFeederLoaded 
		{ 
			get { return this.isFeederLoaded; }
			private set
			{
				if (this.isFeederLoaded != value)
				{
					this.isFeederLoaded = value;

					if (this.isFeederLoaded)
					{
						if (FeederLoaded != null)
							FeederLoaded();
					}
					else
					{
						if (FeederUnloaded != null)
							FeederUnloaded();
					}
				}
			}
		}*/
		#endregion

		#endregion


		//PUBLIC METHODS
		#region public methods

		#region Dispose()
		public void Dispose()
		{
			base.Dispose(this);
		}
		#endregion
	
		#region ScanAdf()
		public void ScanAdf(int operationId, bool duplex, Scanners.ColorMode colorMode, short dpi, double brightness, double contrast)
		{
			if (scanner != null)
			{
				lock (this.locker)
				{
					TurnLightOnAndScanAdf(operationId, duplex, colorMode, dpi, brightness, contrast);
				}
			}
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods

		#region Init()
		protected override void Init(Scanners.ScannerType scannerType)
		{
			base.Init(scannerType);

			try
			{
				scanner.TwainStateChanged += new TwainApp.TwainStateChangedHandler(Scanner_TwainStateChanged);
			}
			catch (Exception ex)
			{
				//throw new Exception("Can't connect to the scanner!" + " "  + ex.Message);
				throw new Exception(ex.Message);
			}
		}
		#endregion

		#region ScanTU()
		protected override void ScanTU(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ColorMode colorMode, Scanners.ScanDocSize docSize, short dpi, double brightness, double contrast)
		{
			this.operationId = operationId;
			scanner.PredefinedScanArea = TwainApp.PredefinedScanArea.None;

			Progress_Changed("Scanning...", 0);

			scanner.Brightness = brightness * 2 - 1;
			scanner.Contrast = contrast * 2 - 1;

			scanner.PixelDepth = GetPixelFormat(colorMode);
			scanner.PixelType = GetPixelType(colorMode);
			scanner.Resolution = dpi;
			scanner.CaptureIndicators = false;
			scanner.TransferCount = 1;

			try
			{
				scanner.Scan();
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Error, "AdfScanner, Scan(): " + ex.Message, ex);
				throw new ScannersEx("Scanning process was not successfull!");
			}
		}
		#endregion

		#region ScanAdfTU()
		void ScanAdfTU(int operationId, bool duplex, Scanners.ColorMode colorMode, short dpi, double brightness, double contrast)
		{
			this.operationId = operationId;
			scanner.PredefinedScanArea = TwainApp.PredefinedScanArea.None;

			Progress_Changed("Scanning...", 0);

			scanner.Brightness = brightness * 2 - 1;
			scanner.Contrast = contrast * 2 - 1;

			scanner.PixelDepth = GetPixelFormat(colorMode);
			scanner.PixelType = GetPixelType(colorMode);
			scanner.Resolution = dpi;
			scanner.CaptureIndicators = false;
			scanner.TransferCount = -1;
			scanner.DocumentFeederDuplexEnabled = duplex; 

			try
			{
				scanner.Scan();
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Error, "AdfScanner, Scan(): " + ex.Message, ex);
				throw new ScannersEx("Scanning process was not successfull!");
			}
		}
		#endregion

		#region Timer_Tick()
		void Timer_Tick(object sender, EventArgs e)
		{
			/*try
			{
				this.timer.Stop();

				if (scanner != null)
				{
					lock (this.locker)
					{
						this.IsFeederLoaded = scanner.DocumentFeederLoaded;

#if DEBUG
						Console.WriteLine("ADF Feeder: " + (this.IsFeederLoaded ? "Loaded" : "Unloaded"));
#endif
					}
					this.timer.Start();
				}
			}
			catch (Exception ex)
			{
				notifications.Notify(this, Notifications.Type.Warning, "The ADF scanner is not accessible. ", ex);
			}*/
		}
		#endregion

		#region TurnLightOnAndScanAdf()
		void TurnLightOnAndScanAdf(int operationId, bool duplex, Scanners.ColorMode colorMode, short dpi, double brightness, double contrast)
		{
			Thread t = new Thread(new ParameterizedThreadStart(TurnLightOnAndScanAdfTU));
			t.Name = "ThreadAdfScanner_TurnLightOnAndScanAdf";
			t.CurrentCulture = Thread.CurrentThread.CurrentCulture;
			t.CurrentUICulture = Thread.CurrentThread.CurrentUICulture;
			t.SetApartmentState(ApartmentState.STA);
			t.Start(new object[] { operationId, duplex, colorMode, dpi, brightness, contrast });
		}
		#endregion

		#region TurnLightOnAndScanAdfTU()
		void TurnLightOnAndScanAdfTU(object obj)
		{
			object[] array = (object[])obj;
			int operationId = (int)array[0];

			try
			{
				bool duplex = (bool)array[1];
				Scanners.ColorMode colorMode = (Scanners.ColorMode)array[2];
				short dpi = (short)array[3];
				double brightness = (double)array[4];
				double contrast = (double)array[5];
				DateTime start = DateTime.Now;

				/*if (scanner.LampState == false)
				{
					Progress_Changed("Warming up Lights...", 0);
					
					while (scanner.LampState == false)
					{
						if (DateTime.Now.Subtract(start).TotalSeconds > 80)
							throw new ScannersEx("Problem with scanner! The light can't be warmed up in reasonable time.");
						else
							Thread.Sleep(1000);
					}
				}*/

				ScanAdfTU(operationId, duplex, colorMode, dpi, brightness, contrast);
			}
			catch (Exception ex)
			{
				Scanner_ScanError(operationId, ex);
			}
		}
		#endregion

		#region Scanner_TwainStateChanged()
		void Scanner_TwainStateChanged(TwainApp.TwainState twainState)
		{	
			if (TwainStateChanged != null)
				TwainStateChanged(twainState);
		}
		#endregion
	
		#endregion

	}

}
