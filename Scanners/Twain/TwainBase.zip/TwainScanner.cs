using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Threading;
using System.Collections.Generic;
using System.Runtime.InteropServices;


namespace Scanners.Twain
{
	public class TwainScanner : TwainBase, IDisposable, IScanner
	{

		#region constructor
		/// <summary>
		/// must be called from main window thread!!!
		/// </summary>
		public TwainScanner()
			: base()
		{
			if (scanner == null)
				Init(Scanners.Settings.Instance.General.ScannerType);

			if (registeredCallers.Contains(this) == false)
				registeredCallers.Add(this);
		}
		#endregion


		//PUBLIC METHODS
		#region public methods

		#region Dispose()
		public void Dispose()
		{
			base.Dispose(this);
		}
		#endregion

		#endregion


		//PROTECTED METHODS
		#region protected methods

		#region ScanTU()
		/// <summary>
		/// 
		/// </summary>
		/// <param name="operationId"></param>
		/// <param name="bookedgeScanMode"></param>
		/// <param name="docSize"></param>
		/// <param name="dpi"></param>
		/// <param name="brightness">interval -1, 1</param>
		/// <param name="contrast">interval -1, 1</param>
		protected override void ScanTU(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ColorMode colorMode, Scanners.ScanDocSize docSize, short dpi, double brightness, double contrast)
		{
			this.operationId = operationId;
			scanner.PredefinedScanArea = TwainApp.PredefinedScanArea.None;

			Progress_Changed("Scanning...", 0);

			if (docSize == Scanners.ScanDocSize.Max)
			{
				scanner.AutomaticBorderDetection = false;
				scanner.AutomaticDeskewDetection = false;
				scanner.UndefinedImageSize = false;
				scanner.AutomaticRotate = false;
			}
			else
			{
				scanner.AutomaticBorderDetection = true;
				scanner.AutomaticDeskewDetection = true;
				scanner.UndefinedImageSize = true;
				scanner.AutomaticRotate = (bookedgeScanMode == Scanners.BookedgeScanMode.Automatic);
			}

			scanner.Brightness = brightness;
			scanner.Contrast = contrast;

			scanner.PixelDepth = GetPixelFormat(colorMode);
			scanner.PixelType = GetPixelType(colorMode);
			scanner.Resolution = dpi;
			scanner.CaptureIndicators = false;
			this.bookedgeScanMode = bookedgeScanMode;
			this.docSize = docSize;

			try
			{
				scanner.Scan();
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Error, "TwainScanner, Scan(): " + ex.Message, ex);
				throw new ScannersEx("Scanning process was not successfull!");
			}
		}
		#endregion

		#endregion

	}
}
