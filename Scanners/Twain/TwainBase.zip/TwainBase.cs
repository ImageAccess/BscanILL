using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Threading;
using System.Collections.Generic;
using System.Runtime.InteropServices;


namespace Scanners.Twain
{
	public class TwainBase
	{
		protected volatile static List<object>	registeredCallers = new List<object>();
		protected static TwainApp.TwainClass	scanner = null;
		protected static  MessageHandler		messageHandler;
		protected static Scanners.DeviceInfo	deviceInfo;
		
		protected Notifications					notifications = Notifications.Instance;
		protected Scanners.ScannerType			scannerType = Scanners.ScannerType.iVinaFB6280E;

		protected Scanners.BookedgeScanMode		bookedgeScanMode = Scanners.BookedgeScanMode.FlatMode;
		protected Scanners.ScanDocSize			docSize = Scanners.ScanDocSize.Auto;
		protected int							operationId = -1;
		protected object						locker = new object();

		public delegate void ImageScannedHnd(int operationId, TwainApp.TwainImage twainImage, Scanners.BookedgeScanMode bookedgeScanMode, bool moreImagesToTransfer);
		public delegate void BitmapScannedHnd(int operationId, Bitmap bitmap, Scanners.BookedgeScanMode bookedgeScanMode, bool moreImagesToTransfer);
		public delegate void ScanErrorHnd(int operationId, Exception ex);
		public delegate void ScannerInitializedHnd(Scanners.DeviceInfo deviceInfo);

		public static event ImageScannedHnd					ImageScanned;
		//public event BitmapScannedHnd					BitmapScanned;
		public event ScanErrorHnd						ScanError;
		public event Scanners.ProgressChangedHnd		ProgressChanged;

		/*[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = false)]
		public static extern IntPtr LoadLibrary(string lpFileName);

		[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = false)]
		public static extern bool FreeLibrary(IntPtr library);

		[DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = false)]
		public static extern IntPtr GetModuleHandle(string lpFileName);*/


		#region constructor
		protected TwainBase()
		{
			if (messageHandler == null)
			{
				messageHandler = new MessageHandler();
				messageHandler.MessageReceived += new MessageHandler.MessageReceivedHnd(MessageHandler_MessageReceived);
			}
		}
		#endregion



		//PUBLIC PROPERTIES
		#region public properties
		public Scanners.DeviceInfo DeviceInfo { get { return deviceInfo; } }

		#region Dpi
		public short Dpi
		{
			get { return (short)scanner.Resolution; }
			set { scanner.Resolution = value; }
		}
		#endregion

		#region Brightness
		/// <summary>
		/// double from interval <-1, 1>
		/// </summary>
		public double Brightness
		{
			get { return scanner.Brightness; }
			set { scanner.Brightness = value; }
		}
		#endregion

		#region Contrast
		/// <summary>
		/// double from interval <-1, 1>
		/// </summary>
		public double Contrast
		{
			get { return scanner.Contrast; }
			set { scanner.Contrast = value; }
		}
		#endregion

		#region ColorMode
		public Scanners.ColorMode ColorMode
		{
			get
			{
				switch (scanner.PixelDepth)
				{
					case PixelFormat.Format1bppIndexed: return Scanners.ColorMode.Bitonal;
					case PixelFormat.Format8bppIndexed: return Scanners.ColorMode.Grayscale;
					default: return Scanners.ColorMode.Color;
				}
			}
			set
			{
				switch (value)
				{
					case Scanners.ColorMode.Bitonal: scanner.PixelDepth = PixelFormat.Format1bppIndexed; break;
					case Scanners.ColorMode.Grayscale: scanner.PixelDepth = PixelFormat.Format8bppIndexed; break;
					default: scanner.PixelDepth = PixelFormat.Format24bppRgb; break;
				}
			}
		}
		#endregion

		#region MaxColorDpi
		public short MaxColorDpi
		{
			get { return 600; }
		}
		#endregion

		#endregion


		// PRIVATE PROPERTIES
		#region private properties

		protected Settings			settings { get { return Settings.Instance; } }

		#endregion


		//PUBLIC METHODS
		#region public methods

		#region Dispose()
		protected void Dispose(object caller)
		{
			if (registeredCallers.Contains(caller))
				registeredCallers.Remove(caller);

			if (registeredCallers.Count == 0)
				HardDispose();
		}
		#endregion

		#region HardDispose()
		public virtual void HardDispose()
		{
			if (scanner != null)
				scanner.Shutdown();

			scanner = null;
			registeredCallers.Clear();

			if (messageHandler != null)
			{
				messageHandler.DestroyHandle();
				messageHandler.ReleaseHandle();
				messageHandler = null;
			}
		}
		#endregion

		#region Scan()
		public void Scan(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ColorMode colorMode, Scanners.ScanDocSize docSize, short dpi, double brightness, double contrast)
		{
			if (scanner != null)
			{
				lock (this.locker)
				{
					/*bool isLightOn;

					try { isLightOn = scanner.LampState; }
					catch { isLightOn = true; }

					if (isLightOn == false)*/
						TurnLightOnAndScan(operationId, bookedgeScanMode, colorMode, docSize, dpi, brightness, contrast);
					/*else
						ScanTU(operationId, bookedgeScanMode, docSize, dpi, brightness, contrast);*/
				}
			}
		}
		#endregion
	
		#region Scan()
		/*public void Scan(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ScanDocSize docSize, short dpi, double brightness, double contrast)
		{
			if (scanner != null)
			{
				lock (locker)
				{
					this.operationId = operationId;
					scanner.PredefinedScanArea = TwainApp.PredefinedScanArea.None;

					if (this.scannerType == Scanners.ScannerType.PlustekOpticBookA300)
					{
						scanner.AutomaticBorderDetection = false;
						scanner.UndefinedImageSize = false;
					}
					else
					{
						if (docSize == Scanners.ScanDocSize.Max)
						{
							scanner.AutomaticBorderDetection = false;
							scanner.AutomaticDeskewDetection = false;
							scanner.UndefinedImageSize = false;
							scanner.AutomaticRotate = false;
						}
						else
						{
							scanner.AutomaticBorderDetection = true;
							scanner.AutomaticDeskewDetection = true;
							scanner.UndefinedImageSize = true;
							scanner.AutomaticRotate = (bookedgeScanMode == Scanners.BookedgeScanMode.Automatic);
						}
					}

					scanner.Resolution = dpi;
					scanner.CaptureIndicators = false;
					this.bookedgeScanMode = bookedgeScanMode;
					this.docSize = docSize;

					try
					{
						scanner.Scan();
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(this, Notifications.Type.Error, "TwainBase, Scan(): " + ex.Message, ex);
						throw new ScannersEx("Scanning process was not successfull!");
					}
				}
			}
		}*/
		#endregion

		#region PingDevice()
		public void PingDevice()
		{
			//scannerQueue.Enqueue(new ScannerOperation(operationId, ScannerOperationType.Ping, null));
		}
		#endregion

		#region Reset()
		public void Reset()
		{
			if (scanner != null)
			{
				lock (locker)
				{
					scanner.PixelDepth = PixelFormat.Format24bppRgb;
					scanner.Resolution = 300;
					scanner.PredefinedScanArea = TwainApp.PredefinedScanArea.None;

					if (Scanners.Scanner.IsAdfScanner(this.scannerType))
					{
					}
					else
					{
						scanner.AutomaticBorderDetection = true;
						scanner.AutomaticDeskewDetection = true;
						scanner.UndefinedImageSize = true;
					}

					scanner.CaptureIndicators = false;
				}
			}
		}
		#endregion

		#region OpenSetupWindow()
		public void OpenSetupWindow()
		{
			if (scanner != null)
				scanner.OpenSettingsWindow();
		}
		#endregion

		#endregion


		//PROTECTED METHODS
		#region protected methods

		#region ScanTU()
		protected virtual void ScanTU(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ColorMode colorMode, Scanners.ScanDocSize docSize, 
			short dpi, double brightness, double contrast)
		{
		}
		#endregion

		#region Init()
		protected virtual void Init(Scanners.ScannerType scannerType)
		{
			try
			{
				IntPtr mainFormHnd = messageHandler.Handle;// new System.Windows.Interop.WindowInteropHelper(mainForm).Handle;
				string serialNumber = "";
				string firmware = "";

				this.scannerType = scannerType;

				if (this.scannerType == Scanners.ScannerType.iVinaFB6280E)
				{
					scanner = new TwainApp.TwainClass(mainFormHnd, "FB6280E");

					scanner.Mirror = false;
					scanner.Rotation = 0;
					scanner.ScanOrientation = TwainApp.ScanOrientation.Rotate0;
					scanner.PixelDepth = PixelFormat.Format24bppRgb;
					scanner.BackgroundColor = TwainApp.BackgroundColor.Black;
					scanner.ICCProfiles = false;
					scanner.FileTransferMode = TwainApp.ScanMode.Memory;
					scanner.Compression = TwainApp.Compression.None;

					this.Brightness = settings.TwainScanner.BrightnessDelta;
					this.Contrast = settings.TwainScanner.ContrastDelta;
					serialNumber = "FB6280E";
				}
				else if (this.scannerType == Scanners.ScannerType.iVinaFB6080E)
				{
					scanner = new TwainApp.TwainClass(mainFormHnd, "FB6080E");

					scanner.Mirror = false;
					scanner.Rotation = 0;
					scanner.ScanOrientation = TwainApp.ScanOrientation.Rotate0;
					scanner.PixelDepth = PixelFormat.Format24bppRgb;
					scanner.BackgroundColor = TwainApp.BackgroundColor.Black;
					scanner.ICCProfiles = false;
					scanner.FileTransferMode = TwainApp.ScanMode.Memory;
					scanner.Compression = TwainApp.Compression.None;

					this.Brightness = settings.TwainScanner.BrightnessDelta;
					this.Contrast = settings.TwainScanner.ContrastDelta;
					serialNumber = "FB6080E";
				}
				else if (this.scannerType == Scanners.ScannerType.KodakI1405)
				{
					scanner = new TwainApp.TwainClass(mainFormHnd, "Kodak Scanner: i14");

					scanner.FileTransferMode = TwainApp.ScanMode.Memory;
					scanner.Compression = TwainApp.Compression.None;
					scanner.KodakIndicatorsWarmUp = false;
					scanner.KodatEnergySavingsTimeout = Math.Max(5, Math.Min(240, this.settings.TwainScanner.EnergyStarTimeout));

					this.Brightness = settings.TwainScanner.BrightnessDelta;
					this.Contrast = settings.TwainScanner.ContrastDelta;
					serialNumber = "i1405";
				}
				else if (this.scannerType == Scanners.ScannerType.KodakI1120)
				{
					scanner = new TwainApp.TwainClass(mainFormHnd, "Kodak Scanner: i11");

					scanner.FileTransferMode = TwainApp.ScanMode.Memory;
					scanner.Compression = TwainApp.Compression.None;
					scanner.KodakIndicatorsWarmUp = false;
					scanner.KodatEnergySavingsTimeout = Math.Max(5, Math.Min(240, this.settings.TwainScanner.EnergyStarTimeout));

					this.Brightness = settings.TwainScanner.BrightnessDelta;
					this.Contrast = settings.TwainScanner.ContrastDelta;

					serialNumber = "i1120";
				}
				else
					throw new Exception("Unexpected scanner type!");


				TwainApp.DeviceInfo twainDeviceInfo = new TwainApp.DeviceInfo();
				scanner.GetDeviceInfo(twainDeviceInfo);

				string productName = twainDeviceInfo.ProductName;

				try
				{
					if (scanner.SerialNumber != null && scanner.SerialNumber.Trim().Length > 0)
						serialNumber += "-" + scanner.SerialNumber;
				}
				catch { }

				try
				{
					if (scanner.Firmware != null && scanner.Firmware.Trim().Length > 0)
						firmware = scanner.Firmware;
					else
						firmware = twainDeviceInfo.Version.MajorNum.ToString() + "." + twainDeviceInfo.Version.MinorNum.ToString();
				}
				catch
				{
					firmware = twainDeviceInfo.Version.MajorNum.ToString() + "." + twainDeviceInfo.Version.MinorNum.ToString();
				}

				deviceInfo = new DeviceInfoTwain(serialNumber, firmware);

				try
				{
#if DEBUG
					Console.WriteLine("EnergySavings: " + scanner.EnergySavings.ToString());
					Console.WriteLine("EnergySavingsTimeout: " + scanner.EnergySavingsTimeout.ToString());
#endif
					
					scanner.EnergySavingsTimeout = Math.Max(1,settings.TwainScanner.EnergyStarTimeout) ;						
					scanner.EnergySavings = settings.TwainScanner.IsEnergyStarOn;
				}
				catch { }
			}
			catch (Exception ex)
			{
				HardDispose();
				notifications.Notify(this, Notifications.Type.Warning, "Can't connect to the scanner!" + " " + ex.Message, ex);
				throw new ScannersEx("Can't connect to the scanner!" + " " + ex.Message);
			}
			
			scanner.ImageScanned += new TwainApp.ImageEventHandler(Scanner_ImageScanned);
			scanner.ScanError += new TwainApp.ErrorEventHandler(Scanner_ScanError);

			Reset();
		}
		#endregion

		#region Progress_Changed()
		protected void Progress_Changed(string description, float progress)
		{
			if (ProgressChanged != null)
				ProgressChanged(description, progress);
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods

		#region Scanner_ImageScanned()
		void Scanner_ImageScanned(TwainApp.TwainImage twainImage, bool moreImagesToTransfer)
		{
			if (twainImage.Bitmap != null)
			{
				if (Scanners.Scanner.IsAdfScanner(this.scannerType))
				{
				}
				else
				{
					//iVina
					/*if (this.bookedgeScanMode == Scanners.BookedgeScanMode.LeftPage)
						twainImage.Bitmap.RotateFlip(RotateFlipType.RotateNoneFlipNone);
					else*/
					if (this.bookedgeScanMode == Scanners.BookedgeScanMode.FlatMode)
					{
						Bitmap b = ImageProcessing.RotationFlipping.Go(twainImage.Bitmap, RotateFlipType.Rotate90FlipNone);
						twainImage.SwapBitmap(b);
					}
					else if (this.bookedgeScanMode == Scanners.BookedgeScanMode.RightPage)
					{
						Bitmap b = ImageProcessing.RotationFlipping.Go(twainImage.Bitmap, RotateFlipType.Rotate180FlipNone);
						twainImage.SwapBitmap(b);
					}
				}

				if (ImageScanned != null)
					ImageScanned(this.operationId, twainImage, this.bookedgeScanMode, moreImagesToTransfer);

				try
				{
					if (this.scannerType == Scanners.ScannerType.iVinaFB6080E || this.scannerType == Scanners.ScannerType.iVinaFB6280E)
					{
						scanner.EnergySavingsTimeout = Math.Max(1, settings.TwainScanner.EnergyStarTimeout);
						scanner.EnergySavings = settings.TwainScanner.IsEnergyStarOn;
					}
				}
#if DEBUG
				catch (Exception ex)
				{
					ex = ex;
				};
#else
				catch { };
#endif
			}
		}
		#endregion

		#region Scanner_ScanError()
		protected void Scanner_ScanError(Exception ex)
		{
			Scanner_ScanError(this.operationId, ex);
		}

		protected void Scanner_ScanError(int operationId, Exception ex)
		{
			if (ScanError != null)
			{
				if (ex.Message.ToLower().Contains("canceled"))
					ScanError(operationId, new ScannersEx(ex.Message));
				else
					ScanError(operationId, ex);
			}
		}
		#endregion

		#region TurnLightOnAndScan()
		void TurnLightOnAndScan(int operationId, Scanners.BookedgeScanMode bookedgeScanMode, Scanners.ColorMode colorMode, Scanners.ScanDocSize docSize, short dpi, double brightness, double contrast)
		{
			Thread t = new Thread(new ParameterizedThreadStart(TurnLightOnAndScanTU));
			t.Name = "ThreadTwainBase_TurnLightOnAndScan";
			t.CurrentCulture = Thread.CurrentThread.CurrentCulture;
			t.CurrentUICulture = Thread.CurrentThread.CurrentUICulture;
			t.SetApartmentState(ApartmentState.STA);
			t.Start(new object[] { operationId, bookedgeScanMode, colorMode, docSize, dpi, brightness, contrast });
		}
		#endregion

		#region TurnLightOnAndScanTU()
		void TurnLightOnAndScanTU(object obj)
		{
			object[] array = (object[])obj;
			int operationId = (int)array[0];
			
			try
			{
				Scanners.BookedgeScanMode bookedgeScanMode = (Scanners.BookedgeScanMode)array[1];
				Scanners.ColorMode colorMode = (Scanners.ColorMode)array[2];
				Scanners.ScanDocSize docSize = (Scanners.ScanDocSize)array[3];
				short dpi = (short)array[4];
				double brightness = (double)array[5];
				double contrast = (double)array[6];
				DateTime start = DateTime.Now;

				if (scanner.LampState == false)
				{
					if (ProgressChanged != null)
						ProgressChanged("Warming up Lights...", 0);

					while (scanner.LampState == false)
					{
						if (DateTime.Now.Subtract(start).TotalSeconds > 60)
							throw new ScannersEx("Problem with scanner! The light can't be warmed up in reasonable time.");
						else
							Thread.Sleep(1000);
					}
				}

				ScanTU(operationId, bookedgeScanMode, colorMode, docSize, dpi, brightness, contrast);
			}
			catch (Exception ex)
			{
				Scanner_ScanError(ex);
			}
		}
		#endregion

		#region GetPixelFormat()
		protected PixelFormat GetPixelFormat(Scanners.ColorMode colorMode)
		{
			switch (colorMode)
			{
				case Scanners.ColorMode.Bitonal: return PixelFormat.Format1bppIndexed;
				case Scanners.ColorMode.Grayscale: return PixelFormat.Format8bppIndexed;
				default: return PixelFormat.Format24bppRgb;
			}
		}
		#endregion

		#region GetPixelType()
		protected TwainApp.PixelType GetPixelType(Scanners.ColorMode colorMode)
		{
			switch (colorMode)
			{
				case Scanners.ColorMode.Bitonal: return TwainApp.PixelType.BW;
				case Scanners.ColorMode.Grayscale: return TwainApp.PixelType.GRAY;
				default: return TwainApp.PixelType.RGB;
			}
		}
		#endregion

		#region MessageHandler_MessageReceived()
		void MessageHandler_MessageReceived(ref System.Windows.Forms.Message msg)
		{
			  if (scanner != null)
				scanner.WndProc(ref msg);
		}
		#endregion

		#endregion

	}

}
