using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Timers;
using System.Net.Cache;
using System.Threading;



namespace Scanners.S2N
{
	public class ScannerS2N : ScannerBase
	{
		static ScannerS2N	instance = null;
		public bool			scanWaitAlive = false;

		System.Timers.Timer timerSaveMode = null;

		bool		isBookeye = true;


		#region constructor
		private ScannerS2N()
		{
			if (Scanners.Settings.Instance.General.SaveModeTimeoutInMins > 0)
			{
				timerSaveMode = new System.Timers.Timer(Scanners.Settings.Instance.General.SaveModeTimeoutInMins * 60000);
				timerSaveMode.Elapsed += new ElapsedEventHandler(TimerSafeMode_Elapsed);
				timerSaveMode.AutoReset = false;
			}

			this.isBookeye = this.DeviceInfo.SerialNumber.ToLower().StartsWith("be");

			if (timerSaveMode != null)
				timerSaveMode.Start();
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties

		public bool					CanTurnOffAutoFocus { get { return this.settings.Autofocus.IsDefined; } }
		public bool					CanTurnOffLights	{ get { return this.settings.Light.IsDefined; } }
		public bool					CanSetDocMode		{ get { return this.settings.DocMode.IsDefined; } }
		public bool					IsBookeye			{ get { return this.isBookeye; } }
		
		public bool					IsLightOn			
		{
			get { return (this.settings != null) ? (this.settings.Light.IsDefined == false || this.settings.Light.Value == LightType.On) : true; }
			set 
			{
				if (this.settings != null && this.settings.Light.IsDefined)
					this.settings.Light.Value = (value) ? LightType.On : LightType.Off;
			}
		}

		#endregion


		//PUBLIC METHODS
		#region public  methods

		#region GetInstance()
		public static ScannerS2N GetInstance()
		{
			if (ScannerS2N.instance == null)
				ScannerS2N.instance = new ScannerS2N();

			return instance;
		}
		#endregion

		#region Dispose()
		public void Dispose()
		{
			Logout();
		}
		#endregion
	
		#region SetDevice()
		public void SetDevice(object sender, string settings)
		{
			try
			{
				ChangeSettingColorToGrayscaleIfNeeded(ref settings);			
			}
			catch (ScannersEx ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				if (ex.Message.Contains("has timed out"))
					Notifications.Instance.Notify(sender, Notifications.Type.Warning, "Can't connect to the scanner!" + " "  + ex.Message, ex);
				else
					Notifications.Instance.Notify(sender, Notifications.Type.Error, "ScannerS2N ChangeSettingColorToGrayscaleIfNeeded('" + settings + "'): " + ex.Message, ex);

				throw new ScannersEx("Scanner doesn't respond." + Environment.NewLine + "_" + ex.Message, ScannersEx.AlertType.Error);
			}

			try
			{			
				//scanning
				string htmlBody = SendCommandToScanner(Command.Set, settings, 5000);

				if (htmlBody.IndexOf("OK") < 0)
				{
					Notifications.Instance.Notify(sender, Notifications.Type.Error, "ScannerS2N SendCommandToScanner1('" + settings + "'): " + Environment.NewLine + htmlBody, null);
					throw new ScannersEx("Scanner doesn't respond.", ScannersEx.AlertType.Error);
				}
			}
			catch (ScannersEx ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				if (ex.Message.Contains("has timed out"))
					Notifications.Instance.Notify(sender, Notifications.Type.Warning, "Can't connect to the scanner!" + " "  + ex.Message, ex);
				else
					Notifications.Instance.Notify(sender, Notifications.Type.Error, "ScannerS2N SendCommandToScanner2('" + settings + "'): " + ex.Message, ex);

				throw new ScannersEx("Scanner doesn't respond." + Environment.NewLine + ex.Message, ScannersEx.AlertType.Error);
			}
		}
		#endregion

		#region Scan()
		/// <summary>
		/// saves image into 'filePath' or throws exception
		/// </summary>
		/// <param name="settings"></param>
		/// <param name="filePath"></param>
		public void Scan(string settings, string filePath)
		{
			lock (threadLocker)
			{
				if (timerSaveMode != null)
					timerSaveMode.Stop();

				HttpWebRequest webRequest = null;
				string htmlBody;

				try
				{
					int delay = TurnTheLightsOn();

					if (delay > 0)
					{
						for (int i = 0; i < delay; i++)
						{
							if (ProgressChanged != null)
							{
								float progress = i / (float)delay;

								ProgressChanged(string.Format("Warming up Lights, {0:0}%.", progress * 100), progress); ;
							}

							Thread.Sleep(1000);
						}
					}

					ChangeSettingColorToGrayscaleIfNeeded(ref settings);

					if (ProgressChanged != null)
						ProgressChanged("Scanning...", 0);

					Login();
					Thread.Sleep(200);

					//setup
					try
					{
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/set?" + this.SessionId + settings);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 5000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								if (streamReader.Peek() >= 0)
								{
									htmlBody = streamReader.ReadToEnd();

									if (htmlBody.IndexOf("OK") < 0)
									{
										Notifications.Instance.Notify(this, Notifications.Type.Error, "ScannerS2N, Scan(): Can't setup scanner!" + Environment.NewLine + htmlBody + Environment.NewLine + "Settings: " + settings, null);
										throw new ScannersEx("Can't setup scanner!");
									}
									else
									{
										if (htmlBody.Contains("light: on"))
											this.IsLightOn = true;
										else if (htmlBody.Contains("light: off"))
											this.IsLightOn = false;
									}
								}
								else
								{
									Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't get scanner response!", null);
									throw new ScannersEx("Can't get scanner response!");
								}
							}
						}
					}
					catch (ScannersEx ex)
					{
						throw ex;
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(this, Notifications.Type.Error, "ScannerS2N, Scan(): Can't setup scanner! " + ex.Message, ex);
						throw new ScannersEx("Can't connect to the scanner!");
					}

					Thread.Sleep(100);

					//scanning
					try
					{
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/scan?" + this.SessionId);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 30000;
						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								htmlBody = streamReader.ReadToEnd();
							}
						}
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(): Exception while sending scan request. " + ex.Message, ex);
						throw new ScannersEx("There is not connection to the scanner!", ScannersEx.AlertType.Warning);
					}

					if (htmlBody.IndexOf("OK") < 0)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(): Invalid parameters returned while sending scan request. " + htmlBody, null);
						throw new ScannersEx("Invalid parameters returned while sending scan request!");
					}

					try
					{
						DownloadPreview();
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(), Get preview Exception:" + ex.Message, ex);
					}

					Thread.Sleep(2000);

					//save image
					webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/image?" + this.SessionId);
					webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
					webRequest.Timeout = 40000;

					using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
					{
						using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
						{

							if (webResponse.ContentType.ToLower().StartsWith("image") == false)
							{
								if (streamReader.Peek() >= 0)
									Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(): Web Response " + webResponse.ContentType + " " + streamReader.ReadToEnd(), null);
								else
									Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(): Web Response " + webResponse.ContentType, null);

								throw new ScannersEx("Can't get image!");
							}
							else
							{
								using (FileStream stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
								{
									int bufferSize = 0x20000;
									byte[] buffer = new byte[bufferSize];
									int bytesRead;

									while ((bytesRead = streamReader.BaseStream.Read(buffer, 0, bufferSize)) > 0)
									{
										stream.Write(buffer, 0, bytesRead);
									}
								}

								if (this.IsColorScanner == false)
								{
									FileInfo fileInfo = new FileInfo(filePath);
									string tempPath = fileInfo.Directory.FullName + @"\" + Path.GetFileNameWithoutExtension(fileInfo.Name) + ".tmp";

									using (ImageProcessing.BigImages.ItDecoder itDecoder = new ImageProcessing.BigImages.ItDecoder(filePath))
									{
										resampling.Resample(itDecoder, tempPath, new ImageProcessing.FileFormat.Jpeg(80), ImageProcessing.PixelsFormat.Format24bppRgb);
									}

									fileInfo.Refresh();
									fileInfo.Delete();
									File.Move(tempPath, filePath);
								}
							}
						}
					}
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, Scan(), Scanner exception while scanning: " + ex.Message, ex);
					throw new ScannersEx("BookEye exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
					timerPingDevice.Start();
					//Logout();
					if (timerSaveMode != null)
						timerSaveMode.Start();
				}
			}
		}
		#endregion

		#region ScanWait()
		/// <summary>
		/// returns null if timeout occured 
		/// </summary>
		/// <param name="settings"></param>
		/// <returns></returns>
		public string ScanWait(string settings, string filePath)
		{
			lock (threadLocker)
			{
				if (timerSaveMode != null)
					timerSaveMode.Stop();

				HttpWebRequest webRequest = null;
				string htmlBody;

				try
				{
					ChangeSettingColorToGrayscaleIfNeeded(ref settings);

					Login();

					//setup
					try
					{
						Thread.Sleep(200);
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/set?" + this.SessionId + settings);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 5000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								if (streamReader.Peek() >= 0)
								{
									htmlBody = streamReader.ReadToEnd();

									if (htmlBody.IndexOf("OK") < 0)
									{
										Notifications.Instance.Notify(this, Notifications.Type.Error, "ScannerS2N, ScanWait(): Can't setup scanner!" + Environment.NewLine + htmlBody + Environment.NewLine + "Settings: " + settings, null);
										throw new ScannersEx("Can't setup scanner!");
									}
									else
									{
										if (htmlBody.Contains("light: on"))
											this.IsLightOn = true;
										else if (htmlBody.Contains("light: off"))
											this.IsLightOn = false;
									}
								}
								else
								{
									Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't get scanner response!", null);
									throw new ScannersEx("Can't get scanner response!");
								}
							}
						}
					}
					catch (ScannersEx ex)
					{
						throw ex;
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(this, Notifications.Type.Warning, "ScannerS2N, ScanWait(): Can't setup scanner! " + ex.Message, ex);
						throw new ScannersEx("Can't connect to the scanner!");
					}
					finally
					{
					}

					Thread.Sleep(100);

					//scanning
					try
					{
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/scan?" + this.SessionId);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 30000;
						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								htmlBody = streamReader.ReadToEnd();
							}
						}
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, ScanWait(): Exception while sending scan request. " + ex.Message, ex);
						throw new ScannersEx("There is not connection to the scanner!", ScannersEx.AlertType.Warning);
					}							
					finally
					{
					}

					if (htmlBody.ToLower().IndexOf("error 7") >= 0)
					{
					}
					else if (htmlBody.IndexOf("OK") < 0 && htmlBody.IndexOf("timeout") < 0)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, ScanWait(): Invalid parameters returned while sending scan request. " + htmlBody, null);
						throw new ScannersEx("Invalid parameters returned while sending scan request!");
					}

					if (htmlBody.IndexOf("OK") >= 0)
					{
						try
						{
							DownloadPreview();
						}
						catch (Exception ex)
						{
							Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, GetThumbnail(), Get preview Exception:" + ex.Message, ex);
						}

						//save image
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/image?" + this.SessionId);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 40000;

						try
						{
							using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
							{
								using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
								{
									if (webResponse.ContentType.ToLower().StartsWith("image") == false)
									{
										if (streamReader.Peek() >= 0)
											Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, ScanWait(): Web Response " + webResponse.ContentType + " " + streamReader.ReadToEnd(), null);
										else
											Notifications.Instance.Notify(null, Notifications.Type.Error, "ScannerS2N, ScanWait(): Web Response " + webResponse.ContentType, null);

										throw new ScannersEx("Can't get image!");
									}
									else
									{
										//scannedImage = new Bitmap(streamReader.BaseStream);

										using (FileStream stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
										{
											int bufferSize = 0x20000;
											byte[] buffer = new byte[bufferSize];
											int bytesRead;

											while ((bytesRead = streamReader.BaseStream.Read(buffer, 0, bufferSize)) > 0)
											{
												stream.Write(buffer, 0, bytesRead);
											}
										}

										if (this.IsColorScanner == false)
										{
											FileInfo fileInfo = new FileInfo(filePath);
											string tempPath = fileInfo.Directory.FullName + @"\" + Path.GetFileNameWithoutExtension(fileInfo.Name) + ".tmp";

											using (ImageProcessing.BigImages.ItDecoder itDecoder = new ImageProcessing.BigImages.ItDecoder(filePath))
											{
												resampling.Resample(itDecoder, tempPath, new ImageProcessing.FileFormat.Jpeg(80), ImageProcessing.PixelsFormat.Format24bppRgb);
											}

											fileInfo.Refresh();
											fileInfo.Delete();
											File.Move(tempPath, filePath);
										}

										return filePath;
									}
								}
							}
						}
						catch (Exception ex)
						{
							throw ex;
						}
						finally
						{
						}
					}
					else
						return null;
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					Notifications.Instance.Notify(null, Notifications.Type.Error, "Scanner exception while scanning:" + " " + ex.Message, ex);
					throw new ScannersEx("BookEye exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
					timerPingDevice.Start();
					//Logout();
					if (timerSaveMode != null)
						timerSaveMode.Start();
				}
			}
		}
		#endregion

		#region StartSaveModeTimer()
		public void StartSaveModeTimer()
		{
			lock (threadLocker)
			{
				if (timerSaveMode != null)
				{
					timerSaveMode.Stop();
					timerSaveMode.Start();
				}
			}
		}
		#endregion

		#region IsBookeye2()
		public static bool IsBookeye2(Scanners.S2nType s2nType)
		{
			switch (s2nType)
			{
				//Bookeye 2
				case Scanners.S2nType.BE2_SCL_N2:
				case Scanners.S2nType.BE2_SGS_N2:
				case Scanners.S2nType.BE2_SCL_R1:
				case Scanners.S2nType.BE2_SCL_R2:
				case Scanners.S2nType.BE2_SGS_R2:
				case Scanners.S2nType.BE2_SGS_R1:
				case Scanners.S2nType.BE2_SCL_R1_PLUS:
				case Scanners.S2nType.BE2_SGS_R1_PLUS:
				case Scanners.S2nType.BE2_SCL_R2_PLUS:
				case Scanners.S2nType.BE2_SGS_R2_PLUS:
				case Scanners.S2nType.BE2_CSL_N2_PLUS:
				case Scanners.S2nType.BE2_SGS_N2_PLUS:
				case Scanners.S2nType.BE2_CGS_N2:
				case Scanners.S2nType.BE2_SGS_N3:
				case Scanners.S2nType.BE2_SCL_N2_R:
					return true;
				default:
					return false;
			}
		}
		#endregion

		#region IsBookeye2N2()
		public static bool IsBookeye2N2(Scanners.S2nType s2nType)
		{
			switch (s2nType)
			{
				//Bookeye 2
				case Scanners.S2nType.BE2_SCL_N2:
				case Scanners.S2nType.BE2_SGS_N2:
				case Scanners.S2nType.BE2_CSL_N2_PLUS:
				case Scanners.S2nType.BE2_SGS_N2_PLUS:
				case Scanners.S2nType.BE2_CGS_N2:
				case Scanners.S2nType.BE2_SCL_N2_R:
					return true;
				default:
					return false;
			}
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods

		#region SendCommandToScanner()
		protected override string SendCommandToScanner(ScannerS2N.Command command, string parameters, int timeout)
		{
			lock (threadLocker)
			{
				string commandStr = (command == Command.Set) ? "set?" : "get?";

				try
				{
					Login();

					Thread.Sleep(250);
					HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/" + commandStr + this.SessionId + parameters);
					webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
					webRequest.Timeout = timeout;

					using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
					{
						using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
						{
							if (reader.Peek() >= 0)
							{
								string response = reader.ReadToEnd();

								if (response.Contains("light:"))
								{
									if (response.Contains("light: on"))
										this.IsLightOn = true;
									else if (response.Contains("light: off"))
										this.IsLightOn = false;
								}

								return response;
							}
							else
								throw new ScannersEx("Can't get scanner response!" );
						}
					}
				}
				catch(Exception ex)
				{
					throw ex;
				}
				finally
				{
					//Logout();
					if (timerPingDevice != null)
						timerPingDevice.Start();

					if (parameters.IndexOf("+light:on") >= 0 && this.timerSaveMode != null)
					{
						this.timerSaveMode.Stop();
						this.timerSaveMode.Start();
					}
				}
			}
		}
		#endregion

		#region TimerSafeMode_Elapsed()
		void TimerSafeMode_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				string htmlBody;
				
				lock (threadLocker)
				{
					htmlBody = SendCommandToScanner(ScannerS2N.Command.Set, "+light:off", 5000);
				}

				if (htmlBody.IndexOf("OK") < 0)
					Notifications.Instance.Notify(this, Notifications.Type.Warning, "Warning: Scanner is not turned on!" + Environment.NewLine + htmlBody, null);
			}
			catch (Exception ex)
			{
				if (ex.Message.ToLower().Contains("timeout"))
					Notifications.Instance.Notify(this, Notifications.Type.Warning, "Warning: Scanner is not turned on!" + " " + ex.Message, ex);
			}
		}
		#endregion

		#region ChangeSettingColorToGrayscaleIfNeeded()
		void ChangeSettingColorToGrayscaleIfNeeded(ref string settings)
		{
			if (settings != null && this.IsColorScanner == false)
			{
				string[] items = settings.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);

				for (int i = 0; i < items.Length; i++)
					if (items[i].ToLower() == "colormode:truecolor")
					{
						items[i] = "colormode:grayscale";
					}

				settings = "";
				for (int i = 0; i < items.Length; i++)
					settings += "+" + items[i];
			}
		}
		#endregion

		#region TurnTheLightsOn()
		/// <summary>
		/// Turns light on if applicable and returns number of seconds needed for the bulbs to warm up.
		/// </summary>
		/// <returns></returns>
		private int TurnTheLightsOn()
		{
			if (this.CanTurnOffLights && this.IsLightOn == false)
			{
				lock (threadLocker)
				{
					try
					{
						//start = DateTime.Now;
						string result = SendCommandToScanner(ScannerS2N.Command.Set, "+light:on", 5000);
						//span = DateTime.Now.Subtract(start);

						if (result.ToLower().Trim().StartsWith("light: on"))
						{
							if (this.deviceInfo.ScannerType == Scanners.ScannerGroup.BE2_N2)
								return 10;
							else if (this.deviceInfo.ScannerType == Scanners.ScannerGroup.BE2_N3)
								return 5;
							else
								return 0;
						}
					}
					catch { }
				}
			}

			return 0;
		}
		#endregion
	
		#endregion

	}
}
