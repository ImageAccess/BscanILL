﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Net;
using System.Net.Cache;
using System.IO;
using System.Threading;
using System.Drawing;
using System.Collections;

namespace Scanners.S2N
{
	/*
	* Warnings

		WARNING 128:  Mechanical problem: Left Book cradle is not adjusted
		WARNING 129:  Mechanical problem: Right Book cradle is not adjusted
		WARNING 130:  Foot Pedal 1: Switch permanently closed
		WARNING 130:  Foot Pedal 1: Switch permanently closed
		WARNING 131:  Foot Pedal 2: Switch permanently closed
		WARNING 131:  Foot Pedal 2: Switch permanently closed

		WARNING 144:  Light level is low
		WARNING 145:  Camera adjustment required
		WARNING 146:  Left lamp blocked
		WARNING 147:  Right lamp blocked

		WARNING 160:  No white balance data

		WARNING 180:  Deskew failed
		WARNING 181:  Stitching2D: out of memory. Using fixed stitching
		WARNING 182:  Ready to feed
		WARNING 183:  Document oversized (Out of Memory)
		WARNING 184:  Failed to execute Auto Exposure (Memory ?),
		WARNING 185:  Failed to execute Adaptive Stitch (Memory ?)
		WARNING 186:  Failed to execute Crop/Deskew (Memory ?
		WARNING 191:  Bookfold failed
		WARNING 192:  Bookfold failed 
		WARNING 193:  Bookfold failed 

		WARNING 194:  Crop failed (left edge!)
		WARNING 195:  Crop failed (right edge!)
		WARNING 196:  Crop failed (upper edge!)
		WARNING 197:  Crop failed (lower edge!)
		WARNING 198:  Crop failed (wide open!)
		WARNING 199:  Crop failed (res2)

	*/
	public abstract class ScannerBase
	{
		protected static object threadLocker = new object();

		string		sessionId = null;
		DateTime	lastLogin = new DateTime(2000, 01, 01);
		
		protected DeviceInfo		deviceInfo;
		protected Bookeye4Settings	settings = null;
		protected int				exceptionIterations = 3;

		protected ImageProcessing.BigImages.Resampling resampling = null;

		protected System.Timers.Timer timerPingDevice = new System.Timers.Timer(290000);
		
		public Scanners.PreviewScannedHnd PreviewScanned;
		public Scanners.ProgressChangedHnd ProgressChanged;


		#region constructor
		public ScannerBase()
		{
			this.SessionId = Properties.ScannersSettings.Default.IpScannerLastSessionId;
			this.deviceInfo = GetDeviceInfo(this.Ip);

			Thread.Sleep(500);

			try
			{
				SetScanner("chopt.cgi?uset+starttimeout+1+admin", 5000);
				SetScanner("chopt.cgi?uset+standby+240+Admin", 5000);
			}
			catch { }

			Thread.Sleep(200);

			string settings = SendCommandToScanner(Scanners.S2N.ScannerS2N.Command.Get, "+settings", 5000);

			this.settings = new Bookeye4Settings(settings);

			if (this.IsColorScanner == false)
				resampling = new ImageProcessing.BigImages.Resampling();

			timerPingDevice.Elapsed += new ElapsedEventHandler(TimerPing_Elapsed);
			timerPingDevice.AutoReset = true;
			timerPingDevice.Start();
		}
		#endregion


		#region enum Command
		public enum Command
		{
			Get,
			Set
		}
		#endregion


		// PUBLIC PROPERTIES
		#region public properties

		public string			Ip				{ get { return Scanners.Settings.Instance.S2NScanner.Ip; } }
		public DeviceInfo		DeviceInfo		{ get { return this.deviceInfo; } }
		public Bookeye4Settings Settings		{ get { return this.settings; } }
		public bool				IsColorScanner	{ get { return this.settings.ColorMode.IsColorOptionInstalled; } }
		public short			MaxColorDpi		{ get { return (short)this.settings.Dpi.Maximum; } }

		#endregion


		//PROTECTED PROPERTIES
		#region protected properties

		#region SessionId
		protected string SessionId
		{
			get { return this.sessionId; }
			set
			{
				this.sessionId = value;
				Properties.ScannersSettings.Default.IpScannerLastSessionId = this.sessionId;
				Properties.ScannersSettings.Default.Save();
			}
		}
		#endregion

		#endregion


		// PUBLIC METHODS
		#region public methods

		#region static GetDeviceInfo()
		public static Scanners.DeviceInfo GetDeviceInfo(string ip)
		{
			return GetDeviceInfoInternal(ip);
		}
		#endregion

		#endregion


		// PRIVATE METHODS
		#region private methods

		protected abstract string SendCommandToScanner(ScannerS2N.Command command, string parameters, int timeout);

		#region SetScanner()
		protected void SetScanner(string command, int timeout)
		{
			HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/" + command);
			webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
			webRequest.Timeout = timeout;

			using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
			{
				using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
				{
					if (reader.Peek() < 0)
						throw new ScannersEx("Can't get scanner response!");
				}
			}
		}
		#endregion

		#region static GetDeviceInfoInternal()
		protected static Scanners.DeviceInfo GetDeviceInfoInternal(string ip)
		{
			try
			{
				//scanning
				string htmlBody = "";
				HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(@"http://" + ip + @"/cgi/s2ninfo");
				webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
				webRequest.Timeout = 3000;
				
				using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
				{
					using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
					{
						if (reader.Peek() >= 0)
							htmlBody = reader.ReadToEnd();
					}
				}

				if (htmlBody.IndexOf("OK") < 0)
				{
					throw new Exception(htmlBody);
					//return Scanners.DeviceInfo.Empty;
				}
				else
				{
					string[] parameters = htmlBody.Split(new char[] { '\n' });
					char[] charArray = new char[] { '\n', '\r' };

					for (int i = 0; i < parameters.Length; i++)
						parameters[i] = parameters[i].Trim(charArray);

					Hashtable hashtable = new Hashtable();
					charArray = new char[] { ':' };

					for (int i = 0; i < parameters.Length; i++)
					{
						if (parameters[i].Length > 0)
						{
							string[] note = parameters[i].Split(charArray);

							hashtable.Add(note[0], note[1].Substring(1));
						}
					}

					Scanners.DeviceInfo deviceInfo = new Scanners.DeviceInfoS2N(ip, (Scanners.S2nType)Convert.ToByte(hashtable["DeviceType"]),
						hashtable["FirmwareVersion"].ToString(), hashtable["hostname"].ToString(), hashtable["devicename"].ToString(), hashtable["netmask"].ToString(),
						hashtable["gateway"].ToString(), hashtable["dhcp"].ToString());

					return deviceInfo;
				}
			}
			catch (Exception ex)
			{
				throw new ScannersEx("Can't connect to the scanner!" + Environment.NewLine + ex.Message, ScannersEx.AlertType.Error);
			}
		}
		#endregion
	
		#region Login()
		protected void Login()
		{
			bool loginNeeded = true;

			timerPingDevice.Stop();

			if (this.SessionId != null && this.SessionId.Length > 0)
			{
				if (DateTime.Now.Subtract(lastLogin).TotalSeconds < 60)
					loginNeeded = false;
				else
				{
					for (int i = 0; i <= exceptionIterations; i++)
					{
						try
						{
							HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/get?" + this.SessionId + "+dpi");
							webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
							webRequest.Timeout = 1000;

							using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
							{
								using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
								{
									if (reader.Peek() >= 0)
									{
										string htmlBody = reader.ReadToEnd();

										if (htmlBody.IndexOf("OK") > 0)
										{
											loginNeeded = false;
											this.lastLogin = DateTime.Now;
											break;
										}
										else
										{
											if (htmlBody.IndexOf("Invalid") >= 0)
											{
												loginNeeded = true;
												break;
											}
										}
									}
								}
							}
						}
						catch (ScannersEx ex)
						{
							throw ex;
						}
						catch (Exception ex)
						{
							if (ex.Message.ToLower().Contains("timed out") && i < exceptionIterations)
								Thread.Sleep(i * 100);
							else
								throw new Exception("Can't open scanner session:" + " " + ex.Message);
						}
					}
				}
			}

			if (loginNeeded)
			{
				for (int i = 0; i <= exceptionIterations; i++)
				{
					try
					{
						HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/s2nopen");
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 5000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								if (reader.Peek() >= 0)
								{
									string line = reader.ReadToEnd();

									if (line.Substring(0, 2).ToUpper() == "ID")
									{
										int indexOf = line.IndexOf('\r');
										this.SessionId = line.Substring(4, indexOf - 4);
										this.lastLogin = DateTime.Now;

										break;
									}
									else
									{
										Notifications.Instance.Notify(null, Notifications.Type.Warning, "Can't open scanner session:" + " " + line, null);
										throw new ScannersEx("Can't open scanner session:" + " " + line, ScannersEx.AlertType.Warning);
									}
								}
								else
								{
									Notifications.Instance.Notify(null, Notifications.Type.Warning, "Can't open scanner session!", null);
									throw new ScannersEx("Can't connect to the scanner!", ScannersEx.AlertType.Error);
								}
							}
						}
					}
					catch (ScannersEx ex)
					{
						throw ex;
					}
					catch (Exception ex)
					{
						if (ex.Message.ToLower().Contains("timed out") && i < exceptionIterations)
							Thread.Sleep(i * 100);
						else
							throw new Exception("Can't open scanner session:" + " " + ex.Message);
					}
				}
			}
		}
		#endregion

		#region Logout()
		internal void Logout()
		{
			try
			{
				if (this.SessionId != null && this.SessionId.Length > 0)
				{
					for (int i = 0; i <= exceptionIterations; i++)
					{
						try
						{
							HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/s2nclose?" + this.SessionId);
							webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
							webRequest.Timeout = 5000;

							using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
							{
								using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
								{
									string line = reader.ReadLine();

									if (line.IndexOf("OK") < 0)
										throw new Exception(line);
								}
							}

							break;
						}
						catch (Exception ex)
						{
							if (ex.Message.ToLower().Contains("timed out") && i < exceptionIterations)
								Thread.Sleep(i * 100);
							else
							{
								//throw new Exception("Can't close scanner session: " + ex.Message);
							}
						}
					}
				}
			}
			finally
			{
				this.SessionId = null;
				timerPingDevice.Start();
			}
		}
		#endregion
	
		#region TimerPing_Elapsed()
		void TimerPing_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				lock (threadLocker)
				{
					string response = SendCommandToScanner(Command.Set, "+speed:2", 5000);

					if (response.Contains("OK") == false)
					{
					}
				}
			}
			catch (Exception ex)
			{
				if (ex.Message.ToLower().Contains("timeout"))
					Notifications.Instance.Notify(this, Notifications.Type.Warning, "Warning: Scanner is not turned on!" + " " + ex.Message, ex);
			}
		}
		#endregion

		#region DownloadPreview()
		protected void DownloadPreview()
		{
			try
			{
				if (PreviewScanned != null)
				{
					//show preview
					HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/preview?" + this.SessionId);
					webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
					webRequest.Timeout = 20000;

					using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
					{
						using (StreamReader thumbReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII, true))
						{
							if (webResponse.ContentType.ToLower().StartsWith("image"))
							{
								Bitmap thumbnail = new Bitmap(thumbReader.BaseStream);
								PreviewScanned(thumbnail);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(null, Notifications.Type.Error, "S2N Scanner, DownloadPreview(): " + ex.Message, ex);
			}
		}
		#endregion

		#endregion

	}
}
