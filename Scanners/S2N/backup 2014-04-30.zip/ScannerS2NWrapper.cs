using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Threading;
using System.Collections.Generic;


namespace Scanners.S2N
{
	public class ScannerS2NWrapper : IScanner
	{
		Scanners.S2N.ScannerS2N		ipScanner = Scanners.S2N.ScannerS2N.GetInstance();
		Notifications				notifications = Notifications.Instance;
		DirectoryInfo				imageDir = new DirectoryInfo(Settings.Instance.General.TempImagesDir);
		Scanners.FileFormat			fileFormat = FileFormat.Jpeg;

		bool						scannerButtonsActive = false;
		object						scannerButtonsActivationLocker = new object();
		
		Scanners.ScanDocSize		paperSize = Scanners.ScanDocSize.Auto;
		Scanners.ColorMode			colorMode = Scanners.ColorMode.Grayscale;
		short						dpi = 300;
		double						brightness = 0;
		double						contrast = 0;
		bool						isAutoFocusOn = true;

		List<ScannerOperation>	scannerQueue = new List<ScannerOperation>();
		object					scannerQueueLocker = new object();
		bool					stopMessagePump = false;
		AutoResetEvent messagePumpLocker = new AutoResetEvent(false);

		public event Scanners.ImageScannedHnd PreviewScanned;
		public event Scanners.FileScannedHnd ImageScanned;
		public event Scanners.OperationSuccessfullHnd OperationSuccessfull;
		public event Scanners.OperationErrorHnd OperationError;
		public event Scanners.ProgressChangedHnd ProgressChanged;


		#region constructor
		public ScannerS2NWrapper()
		{			
			//Thread.Sleep(500);

			Thread thread = new Thread(new ThreadStart(MessagePump));
			thread.Name = "ThreadS2NShared_MessagePump";
			thread.CurrentCulture = System.Threading.Thread.CurrentThread.CurrentCulture;
			thread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentUICulture;
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();

			//ipScanner.AssignPreviewDelegate(dlgShowPreview);
			ipScanner.PreviewScanned += delegate(Bitmap preview)
			{
				if (PreviewScanned != null)
					PreviewScanned(-1, preview);
			};
			ipScanner.ProgressChanged += delegate(string description, float progress)
			{
				if(ProgressChanged != null)
					ProgressChanged(description, progress);
			};
		}
		#endregion


		#region ScannerOperationType
		protected enum ScannerOperationType
		{
			SetDevice,
			Scan
		}
		#endregion

		#region ScannerOperation
		protected class ScannerOperation
		{
			public int OperationId;
			public ScannerOperationType OperationType;
			public object Parameters;

			public ScannerOperation(int operationId, ScannerOperationType operationType, object parameters)
			{
				this.OperationId = operationId;
				this.OperationType = operationType;
				this.Parameters = parameters;
			}
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties
		public Scanners.DeviceInfo		DeviceInfo { get { return ipScanner.DeviceInfo; } }
		//public Scanners.S2N.ScannerS2N Scanner { get { return ipScanner; } }
		public bool						CanTurnOffAutoFocus { get { return this.ipScanner.CanTurnOffAutoFocus; } }
		public bool						CanTurnOffLights { get { return this.ipScanner.CanTurnOffLights; } }
		public bool						CanSetDocMode { get { return this.ipScanner.CanSetDocMode; } }
		public short					MaxColorDpi { get { return this.ipScanner.MaxColorDpi; } }
		public bool						IsBookeye { get { return this.ipScanner.IsBookeye; } }
		public bool						IsLightOn { get { return this.ipScanner.IsLightOn; } }

		#region IsPedalAndButtonsActive
		public bool IsPedalAndButtonsActive
		{
			get { return this.scannerButtonsActive; }
			set
			{
				lock (scannerButtonsActivationLocker)
				{
					this.scannerButtonsActive = true;
				}
			}
		}
		#endregion

		#region ScanFormat
		public Scanners.ScanDocSize ScanDocSize
		{
			get { return this.paperSize; }
			protected set { this.paperSize = value; }
		}
		#endregion

		#region ColorMode
		public Scanners.ColorMode ColorMode
		{
			get { return this.colorMode; }
			protected set { this.colorMode = value; }
		}
		#endregion

		#region FileFormat
		public Scanners.FileFormat FileFormat
		{
			get { return this.fileFormat; }
			protected set { this.fileFormat = value; }
		}
		#endregion
	
		#region Dpi
		public short Dpi
		{
			get { return this.dpi; }
			protected set { this.dpi = value; }
		}
		#endregion

		#region Brightness
		/// <summary>
		/// in interval -1, 1
		/// </summary>
		public double Brightness
		{
			get { return this.brightness; }
			protected set { this.brightness = Math.Max(-1, Math.Min(1, value)); }
		}
		#endregion

		#region Contrast
		/// <summary>
		/// in interval -1, 1
		/// </summary>
		public double Contrast
		{
			get { return this.contrast; }
			protected set { this.contrast = Math.Max(-1, Math.Min(1, value)); }
		}
		#endregion

		#region IsAutoFocusOn
		public bool IsAutoFocusOn
		{
			get { return this.isAutoFocusOn; }
			protected set { this.isAutoFocusOn = value; }
		}
		#endregion

		#endregion


		//PUBLIC METHODS
		#region public methods

		#region Dispose()
		public void Dispose()
		{
			this.IsPedalAndButtonsActive = false;
			this.stopMessagePump = true;
			messagePumpLocker.WaitOne(30000);
			ipScanner.Dispose();
		}
		#endregion

		#region ChangeSettings()
		/// <summary>
		/// 
		/// </summary>
		/// <param name="operationId"></param>
		/// <param name="docSize"></param>
		/// <param name="colorMode"></param>
		/// <param name="dpi"></param>
		/// <param name="brightness">in interval -1, 1</param>
		/// <param name="contrast">in interval -1, 1</param>
		/// <param name="autoFocus"></param>
		public void ChangeSettings(int operationId, Scanners.ScanDocSize docSize, Scanners.ColorMode colorMode, short dpi, double brightness, double contrast, bool autoFocus)
		{
			lock (this)
			{
				this.ScanDocSize = docSize;
				this.ColorMode = colorMode;
				this.Dpi = dpi;
				this.Brightness = brightness;
				this.Contrast = contrast;
				this.IsAutoFocusOn = autoFocus;

				string scanSettings = GetSettingsText();

				try
				{
					lock (this.scannerQueueLocker)
					{
						//remove all scanners sets from the end of the queue
						for (int i = scannerQueue.Count - 1; i >= 0; i--)
						{
							if (scannerQueue[i].OperationType == ScannerOperationType.SetDevice)
								scannerQueue.RemoveAt(i);
							else
								break;
						}

						scannerQueue.Add(new ScannerOperation(operationId, ScannerOperationType.SetDevice, scanSettings));
					}
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					notifications.Notify(this, Notifications.Type.Error, "ScannerS2NShared ChangeSettings(): " + ex.Message + Environment.NewLine + Environment.NewLine + scanSettings, ex);
					throw new ScannersEx("Scanner exception while changing settings:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
				}
			}
		}
		#endregion
	
		#region Scan()
		/// <summary>
		/// 
		/// </summary>
		/// <param name="operationId"></param>
		/// <param name="docSize"></param>
		/// <param name="colorMode"></param>
		/// <param name="fileFormat"></param>
		/// <param name="dpi"></param>
		/// <param name="brightness">in interval -1, 1</param>
		/// <param name="contrast">in interval -1, 1</param>
		/// <param name="autoFocus"></param>
		public void Scan(int operationId, Scanners.ScanDocSize docSize, Scanners.ColorMode colorMode, Scanners.FileFormat fileFormat, short dpi, double brightness, double contrast, bool autoFocus)
		{
			lock (this)
			{
				this.ScanDocSize = docSize;
				this.ColorMode = colorMode;
				this.Dpi = dpi;
				this.Brightness = brightness;
				this.Contrast = contrast;
				this.IsAutoFocusOn = autoFocus;
				this.FileFormat = fileFormat;

				string scanSettings = GetSettingsText();

				try
				{
					lock (this.scannerQueueLocker)
					{
						//remove all scanners sets from the end of the queue
						for (int i = scannerQueue.Count - 1; i >= 0; i--)
						{
							if (scannerQueue[i].OperationType == ScannerOperationType.SetDevice)
								scannerQueue.RemoveAt(i);
							else
								break;
						}
						
						scannerQueue.Add(new ScannerOperation(operationId, ScannerOperationType.Scan, scanSettings));
					}
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					notifications.Notify(this, Notifications.Type.Error, "ScannerS2NShared Scan(): " + ex.Message + Environment.NewLine + Environment.NewLine + scanSettings, ex);
					throw new ScannersEx("Scanner exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
				}
			}
		}
		#endregion

		#region SetDeviceTurbo()
		public void SetDeviceTurbo(int operationId, bool userDocSize, Rectangle rectInMm, bool autofocusOn)
		{
			string autofocusText = (this.CanTurnOffAutoFocus) ? ("+autofocus:" + (autofocusOn ? "on" : "off")) : "";
			string rect = string.Format("+user_x:{0}+user_y:{1}+user_w:{2}+user_h:{3}", rectInMm.X, rectInMm.Y, rectInMm.Width, rectInMm.Height);
			string docSize = (userDocSize) ? "+docsize:user" : "+docsize:auto";
			string scanSettings = docSize + "+user_unit:mm" + rect + autofocusText;

			lock (this.scannerQueueLocker)
			{
				//remove all scanners sets from the end of the queue
				for (int i = scannerQueue.Count - 1; i >= 0; i--)
				{
					if (scannerQueue[i].OperationType == ScannerOperationType.SetDevice)
						scannerQueue.RemoveAt(i);
					else
						break;
				}
				
				scannerQueue.Add(new ScannerOperation(operationId, ScannerOperationType.SetDevice, scanSettings));
			}
		}
		#endregion

		#region Reset()
		public void Reset(int operationId)
		{
			this.ScanDocSize = Scanners.ScanDocSize.Auto;
			this.ColorMode = Scanners.ColorMode.Color;
			this.FileFormat = Scanners.FileFormat.Jpeg;
			this.Dpi = 300;
			this.Brightness = 0;
			this.Contrast = 0;

			this.IsPedalAndButtonsActive = false;
		}
		#endregion
	
		#region GetSettingsText()
		public string GetSettingsText()
		{
			return GetDocSizeText() + GetColorModeText() + GetFileFormatText() + GetScanBrightnessText() + GetScanContrastText() + GetDpiText() +
				GetSpeedText(2) + GetLightText(true) + GetScanModeText(true) + GetAutofocusText(isAutoFocusOn);
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods

		#region GetDocSizeText()
		protected string GetDocSizeText()
		{
			string text = CanSetDocMode ? "+docmode:0" : "";
			
			switch(this.ScanDocSize)
			{
				case Scanners.ScanDocSize.User:
					text += "+docsize:user+splitting:off";
					break;
				case Scanners.ScanDocSize.LetterLandscape:
				case Scanners.ScanDocSize.Letter:
					text += "+docsize:letl+splitting:off" ;
					break ;
				case Scanners.ScanDocSize.LetterLeft :
					text += "+docsize:usbl+splitting:left" ;
					break ;
				case Scanners.ScanDocSize.LetterRight :
					text += "+docsize:usbl+splitting:right" ;
					break ;
				case Scanners.ScanDocSize.Legal :
					text += "+docsize:legl+splitting:off" ;
					break ;
				case Scanners.ScanDocSize.DoubleLetter:
					text += "+docsize:usbl+splitting:off";
					break;
				case Scanners.ScanDocSize.Max :
					text += "+docsize:maxl+splitting:off" ;
					break ;
				case Scanners.ScanDocSize.MaxLeft :
					text += "+docsize:maxl+splitting:left" ;
					break ;
				case Scanners.ScanDocSize.MaxRight :
					text += "+docsize:maxl+splitting:right" ;
					break ;
				case Scanners.ScanDocSize.AutoLeft :
					text += "+docsize:auto+splitting:left" ;
					break ;
				case Scanners.ScanDocSize.AutoRight :
					text += "+docsize:auto+splitting:right" ;
					break ;
				case Scanners.ScanDocSize.Book :
				case Scanners.ScanDocSize.BookLeft :
				case Scanners.ScanDocSize.BookRight :
				case Scanners.ScanDocSize.BookBoth :
					text += "+docsize:auto+splitting:off";
					break ;
				case Scanners.ScanDocSize.AutoBoth :
					text += "+docsize:auto+splitting:off";
					break ;

				default :
					text += "+docsize:auto+splitting:off" ;
					break ;
			}

			return text ;
		}
		#endregion

		#region GetColorModeText()
		protected string GetColorModeText()
		{
			switch (this.ColorMode)
			{
				case Scanners.ColorMode.Bitonal: return "+colormode:lineart";
				case Scanners.ColorMode.Grayscale: return "+colormode:grayscale";
				default: return (this.ipScanner.IsColorScanner) ? "+colormode:truecolor" : "+colormode:grayscale";
			}
		}
		#endregion

		#region GetFileFormatText()
		protected string GetFileFormatText()
		{
			switch (this.FileFormat)
			{
				case Scanners.FileFormat.Jpeg: return "+fileformat:jpeg+jpeg_quality:85";
				default: return "+fileformat:tiff";
			}	
		}
		#endregion

		#region GetDpiText()
		protected virtual string GetDpiText()
		{
			if (this.Dpi <= this.MaxColorDpi)
				return string.Format("+dpi:{0}", Math.Max(300, (int)this.Dpi));
			else
				return "+dpi:" + this.MaxColorDpi.ToString();
		}
		#endregion

		#region GetScanBrightnessText()
		protected string GetScanBrightnessText()
		{
			return "+bright:" + Convert.ToByte(((this.Brightness + 1.0) / 2.0) * 255);
		}
		#endregion

		#region GetScanContrastText()
		protected string GetScanContrastText()
		{
			return "+contr:" + Convert.ToByte(((this.Contrast + 1.0) / 2.0) * 255);
		}
		#endregion

		#region GetSpeedText()
		protected string GetSpeedText(int speed)
		{
			return "+speed:" + speed.ToString();
		}
		#endregion

		#region GetLightText()
		protected string GetLightText(bool lightsOn)
		{
			if (this.CanTurnOffLights)
				return (lightsOn) ? "+light:on" : "+light:off";
			else
				return "";
		}
		#endregion

		#region GetAutofocusText()
		protected string GetAutofocusText(bool autofocusOn)
		{
			if (this.CanTurnOffAutoFocus)
				return (autofocusOn) ? "+autofocus:on" : "+autofocus:off";
			else
				return "";
		}
		#endregion

		#region GetScanModeText()
		protected string GetScanModeText(bool direct)
		{
			if (direct)
				return "+scanmode:direct";
			else
				return "+scanmode:wait";
		}
		#endregion

		#region MessagePump()
		private void MessagePump()
		{
			while (this.stopMessagePump == false)
			{
				try
				{
					ScannerOperation operation = null;

					lock (this.scannerQueueLocker)
					{
						if (scannerQueue.Count > 0)
						{
							operation = scannerQueue[0];
							scannerQueue.RemoveAt(0);
						}
					}

					if (operation != null)
					{
						switch (operation.OperationType)
						{
							case ScannerOperationType.SetDevice: SetDevice_Thread(operation.OperationId, (string)operation.Parameters); break;
							case ScannerOperationType.Scan: Scan_Thread(operation.OperationId, (string)operation.Parameters); break;
						}
					}
					else
					{
						if (this.scannerButtonsActive)
							ScanWait_Thread();

						Thread.Sleep(100);
					}

				}
				catch (Exception ex)
				{
					lock (scannerButtonsActivationLocker)
					{
						this.scannerButtonsActive = false;
					}

					ipScanner.Logout();
					RaiseOperationError(-1, ex);
				}
			}

			this.messagePumpLocker.Set();
		}
		#endregion

		#region ScanWait_Thread()
		private void ScanWait_Thread()
		{
			try
			{
				string scanSettings;
				string docModeText = (this.CanSetDocMode) ? "+docmode:0" : "";

				scanSettings = GetDocSizeText() + GetColorModeText() + GetFileFormatText() + GetScanBrightnessText() + GetScanContrastText() +
					GetDpiText() + GetSpeedText(2) + GetLightText(true) + GetScanModeText(false);

				Thread.Sleep(100);
				string filePath = string.Format("{0}\\{1}.jpg", imageDir.FullName, DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss-ff"));
				string fileScanned = ipScanner.ScanWait(scanSettings, filePath);

				if (fileScanned != null)
					ImageScanned(-1, fileScanned);
			}
			catch (Exception ex)
			{
				lock (scannerButtonsActivationLocker)
				{
					this.scannerButtonsActive = false;
				}

				ipScanner.Logout();
				RaiseOperationError(-1, ex);
			}
		}
		#endregion

		#region SetDevice_Thread()
		private void SetDevice_Thread(int operationId, string scanSettings)
		{
			try
			{
				Thread.Sleep(100);
				ipScanner.SetDevice(this, scanSettings);
				RaiseOperationSuccessfull(operationId);
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't setup scanner!" + " " + ex.Message, ex);
				RaiseOperationError(operationId, ex);
			}
		}
		#endregion

		#region Scan_Thread()
		private void Scan_Thread(int operationId, string scanSettings)
		{
			try
			{
				Thread.Sleep(100);
				string filePath = string.Format("{0}\\{1}.jpg", imageDir.FullName, DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss-ff"));
				ipScanner.Scan(scanSettings, filePath);

				ImageScanned(operationId, filePath);
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't scan image!" + " " + ex.Message, ex);
				RaiseOperationError(operationId, ex);
			}
		}
		#endregion

		#region RaiseOperationSuccessfull()
		protected void RaiseOperationSuccessfull(int operationId)
		{
			try
			{
				if (OperationSuccessfull != null)
					OperationSuccessfull(operationId);
			}
			catch { }
		}
		#endregion
	
		#region RaiseOperationError()
		protected void RaiseOperationError(int operationId, Exception ex)
		{
			try
			{
				if (OperationError != null)
					OperationError(operationId, ex);
			}
			catch { }
		}
		#endregion
	
		#endregion

	}
}
