using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Threading;
using System.Collections.Generic;


namespace Scanners.S2N
{
	public class Bookeye4Wrapper : IScanner
	{
		Scanners.S2N.Bookeye4		scanner = null;
		Notifications				notifications = null;
		DirectoryInfo				imageDir = null;

		//bool						scannerButtonsActive = false;
		object						scannerButtonsActivationLocker = new object();
		
		Scanners.ColorMode			colorMode = Scanners.ColorMode.Grayscale;
		Scanners.FileFormat			fileFormat = FileFormat.Jpeg;
		short						dpi = 300;
		double						brightness = 0.5;
		double						contrast = 0.5;
		Scanners.CradlePosition		cradlePosition = Scanners.CradlePosition.Auto;
		Scanners.S2N.SplittingType	splitting = SplittingType.Off;

		List<ScannerOperation>	scannerQueue = new List<ScannerOperation>();
		object					scannerQueueLocker = new object();
		bool					stopMessagePump = false;
		AutoResetEvent			messagePumpLocker = new AutoResetEvent(false);

		public event Scanners.ImageScannedHnd		PreviewScanned;
		public event Scanners.FileScannedHnd		ImageScanned;
		public event Bookeye4.ScanRequestHnd		ScanRequest;
		
		//public event Scanners.OperationSuccessfullHnd OperationSuccessfull;
		public event Scanners.OperationErrorHnd OperationError;
		public event Scanners.ProgressChangedHnd ProgressChanged;


		#region constructor
		public Bookeye4Wrapper()
		{			
			//Thread.Sleep(500);
			scanner = Scanners.S2N.Bookeye4.GetInstance();
			notifications = Notifications.Instance;
			imageDir = new DirectoryInfo(Scanners.Settings.Instance.General.TempImagesDir);

			Thread thread = new Thread(new ThreadStart(MessagePump));
			thread.Name = "ThreadBookeye4Shared_MessagePump";
			thread.CurrentCulture = System.Threading.Thread.CurrentThread.CurrentCulture;
			thread.CurrentUICulture = System.Threading.Thread.CurrentThread.CurrentUICulture;
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();

			//scanner.AssignPreviewDelegate(dlgShowPreview);
			scanner.PreviewScanned += delegate(Bitmap preview)
			{
				if (PreviewScanned != null)
					PreviewScanned(-1, preview);
			};

			scanner.ProgressChanged += delegate(string description, float progress)
			{
				if(ProgressChanged != null)
					ProgressChanged(description, progress);
			};

			this.scanner.ScanRequest += delegate(Bookeye4.ScannerScanAreaSelection scanArea)
			{
				if (this.ScanRequest != null)
					this.ScanRequest(scanArea);
			}; 
		}
		#endregion


		#region ScannerOperationType
		protected enum ScannerOperationType
		{
			//SetDevice,
			Scan/*,
			Ping*/
		}
		#endregion

		#region ScannerOperation
		protected class ScannerOperation
		{
			public int OperationId;
			public ScannerOperationType OperationType;
			public object Parameters;

			public ScannerOperation(int operationId, ScannerOperationType operationType, object parameters)
			{
				this.OperationId = operationId;
				this.OperationType = operationType;
				this.Parameters = parameters;
			}
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties
		public Scanners.DeviceInfo	DeviceInfo { get { return scanner.DeviceInfo; } }
		public short				MaxColorDpi { get { return this.scanner.MaxColorDpi; } }

		#region ScanDocSize
		public Scanners.ScanDocSize ScanDocSize
		{
			get
			{
				switch (this.scanner.Settings.DocSize.Value)
				{
					case Scanners.S2N.DocumentSizeType.LetterLandscape: return Scanners.ScanDocSize.LetterLandscape;
					case Scanners.S2N.DocumentSizeType.LetterPortraitLeft: return Scanners.ScanDocSize.LetterLeft;
					case Scanners.S2N.DocumentSizeType.LetterPortraitRight: return Scanners.ScanDocSize.LetterRight;
					case Scanners.S2N.DocumentSizeType.MaximumLandscape: return Scanners.ScanDocSize.Max;
					case Scanners.S2N.DocumentSizeType.MaximumPortraitLeft: return Scanners.ScanDocSize.MaxLeft;
					case Scanners.S2N.DocumentSizeType.MaximumPortraitRight: return Scanners.ScanDocSize.MaxRight;
					case Scanners.S2N.DocumentSizeType.LegalLandscape: return Scanners.ScanDocSize.Legal;
					case Scanners.S2N.DocumentSizeType.User: return Scanners.ScanDocSize.User;
					default: return Scanners.ScanDocSize.Auto;
				}
			}
			protected set
			{
				switch (value)
				{
					case Scanners.ScanDocSize.DoubleLetter: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.X11x17Landscape; break;
					case Scanners.ScanDocSize.Legal: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LegalLandscape; break;
					case Scanners.ScanDocSize.Letter: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterLandscape; break;
					case Scanners.ScanDocSize.LetterLandscape: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterLandscape; break;
					case Scanners.ScanDocSize.LetterLeft: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterPortraitLeft; break;
					case Scanners.ScanDocSize.LetterRight: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterPortraitRight; break;
					case Scanners.ScanDocSize.Max: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumLandscape; break;
					case Scanners.ScanDocSize.MaxLeft: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumPortraitLeft; break;
					case Scanners.ScanDocSize.MaxRight: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumPortraitRight; break;
					case Scanners.ScanDocSize.User: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.User; break;
					default: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.Auto; break;
				}
			}
		}
		#endregion

		#region ColorMode
		public Scanners.ColorMode ColorMode
		{
			get { return this.colorMode; }
			protected set {this.colorMode = value; }
		}
		#endregion

		#region FileFormat
		public Scanners.FileFormat FileFormat
		{
			get { return this.fileFormat; }
			protected set { this.fileFormat = value; }
		}
		#endregion

		#region Dpi
		public short Dpi
		{
			get { return this.dpi; }
			protected set { this.dpi = value; }
		}
		#endregion

		#region Brightness
		public double Brightness
		{
			get { return this.brightness; }
			protected set { this.brightness = Math.Max(0, Math.Min(1, value)); }
		}
		#endregion

		#region Contrast
		public double Contrast
		{
			get { return this.contrast; }
			protected set { this.contrast = Math.Max(0, Math.Min(1, value)); }
		}
		#endregion

		#region CradlePosition
		public Scanners.CradlePosition CradlePosition
		{
			get { return this.cradlePosition; }
			protected set { this.cradlePosition = value; }
		}
		#endregion

		#region Splitting
		public Scanners.S2N.SplittingType Splitting
		{
			get { return this.splitting; }
			protected set { this.splitting = value; }
		}
		#endregion

		#region Bookeye4Settings
		public Bookeye4Settings Settings
		{
			get { return this.scanner.Settings; }
		}
		#endregion

		#endregion


		//PUBLIC METHODS
		#region public methods

		#region Dispose()
		public void Dispose()
		{
			//DeactivateScannerButtons();
			StopScannerTouchScreenMonitoring();
			this.stopMessagePump = true;
			messagePumpLocker.WaitOne(30000);
			scanner.Dispose();
		}
		#endregion
	
		#region Scan()
		/// <summary>
		/// 
		/// </summary>
		/// <param name="operationId"></param>
		/// <param name="docSize"></param>
		/// <param name="colorMode"></param>
		/// <param name="fileFormat"></param>
		/// <param name="dpi"></param>
		/// <param name="brightness">from -1 to 1</param>
		/// <param name="contrast">from -1 to 1</param>
		/// <param name="cradlePosition"></param>
		public void Scan(int operationId, Scanners.ScanDocSize docSize, Scanners.ColorMode colorMode, Scanners.FileFormat fileFormat, short dpi, double brightness, double contrast, Scanners.CradlePosition cradlePosition)
		{
			lock (this)
			{
				this.ScanDocSize = docSize;
				this.ColorMode = colorMode;
				this.FileFormat = fileFormat;
				this.Dpi = dpi;
				this.Brightness = brightness;
				this.Contrast = contrast;
				this.CradlePosition = cradlePosition;

				SetScanner();

				try
				{
					lock (this.scannerQueueLocker)
					{					
						scannerQueue.Add(new ScannerOperation(operationId, ScannerOperationType.Scan, ""));
					}
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					notifications.Notify(this, Notifications.Type.Error, "Bookeye4Shared Scan(): " + ex.Message, ex);
					throw new ScannersEx("Scanner exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
				}
			}
		}
		#endregion

		#region PingDevice()
		/*public void PingDevice(int operationId)
		{
			lock (this.scannerQueueLocker)
			{
				scannerQueue.Add(new ScannerOperation(operationId, ScannerOperationType.Ping, null));
			}
		}*/
		#endregion

		#region SetDeviceTurbo()
		public void SetDeviceTurbo(bool userDocSize, Rectangle rectInMil)
		{
			if (userDocSize)
			{
				this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.User;
				this.scanner.Settings.UserX.Value = Math.Max(this.scanner.Settings.UserX.Minimum, Math.Min(this.scanner.Settings.UserX.Maximum, rectInMil.X));
				this.scanner.Settings.UserY.Value = Math.Max(this.scanner.Settings.UserY.Minimum, Math.Min(this.scanner.Settings.UserY.Maximum, rectInMil.Y));
				this.scanner.Settings.UserW.Value = Math.Max(this.scanner.Settings.UserW.Minimum, Math.Min(this.scanner.Settings.UserW.Maximum, rectInMil.Width));
				this.scanner.Settings.UserH.Value = Math.Max(this.scanner.Settings.UserH.Minimum, Math.Min(this.scanner.Settings.UserH.Maximum, rectInMil.Height));
			}
			else
				this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.Auto;
		}
		#endregion

		#region Reset()
		public void Reset(int operationId)
		{
			this.ScanDocSize = Scanners.ScanDocSize.Auto;
			this.ColorMode = Scanners.ColorMode.Color;
			this.FileFormat = Scanners.FileFormat.Jpeg;
			this.Dpi = 300;
			this.Brightness = 0.5;
			this.Contrast = 0.5;

			//DeactivateScannerButtons();
			StopScannerTouchScreenMonitoring();
			
			try
			{
				this.scanner.LockUi();
			}
			catch { }

			this.scanner.Settings.SettingsChanged = true;
		}
		#endregion
	
		#region GetSettingsText()
		public string GetSettingsText()
		{
			if (this.scanner != null)
				return this.scanner.Settings.ToString();
			else
				return "";
		}
		#endregion

		#region LockScannerUi()
		public void LockScannerUi()
		{
			lock (scannerButtonsActivationLocker)
			{
				if (this.scanner != null)
					this.scanner.LockUi();
			}
		}
		#endregion

		#region UnlockScannerUi()
		public void UnlockScannerUi()
		{
			lock (scannerButtonsActivationLocker)
			{
				if (this.scanner != null)
					this.scanner.UnlockUi();
			}
		}
		#endregion

		#region StartScannerTouchScreenMonitoring()
		public void StartScannerTouchScreenMonitoring()
		{
			if (this.scanner != null && scanner.IsTouchScreenMonitoringRunning == false)
			{
				// to reset scan buttons stack
				Scanners.S2N.Bookeye4.ScannerScanAreaSelection scanAreaSelection = Bookeye4.ScannerScanAreaSelection.Flat;
				scanner.ScannerScanButtonPressed(ref scanAreaSelection);

				scanner.StartScannerTouchScreenMonitoring();
			}
		}
		#endregion

		#region StopScannerTouchScreenMonitoring()
		public void StopScannerTouchScreenMonitoring()
		{
			if (this.scanner != null)
			{
				scanner.StopScannerTouchScreenMonitoring();
			}
		}
		#endregion

		#region GetDpi()
		public virtual int GetDpi()
		{
			return Math.Min(this.MaxColorDpi, (int)this.Dpi);
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods

		#region MessagePump()
		private void MessagePump()
		{
			while (this.stopMessagePump == false)
			{
				try
				{
					ScannerOperation operation = null;

					lock (this.scannerQueueLocker)
					{
						if (scannerQueue.Count > 0)
						{
							operation = scannerQueue[0];
							scannerQueue.RemoveAt(0);
						}
					}

					if (operation != null)
					{
						switch (operation.OperationType)
						{
							//case ScannerOperationType.Ping: Ping_Thread(operation.OperationId); break;
							//case ScannerOperationType.SetDevice: SetDevice_Thread(operation.OperationId, (string)operation.Parameters); break;
							case ScannerOperationType.Scan: Scan_Thread(operation.OperationId, (string)operation.Parameters); break;
						}
					}
					else
					{
						/*if (this.scannerButtonsActive)
							ScanWait_Thread();*/

						Thread.Sleep(100);
					}

				}
				catch (Exception ex)
				{
					/*lock (scannerButtonsActivationLocker)
					{
						this.scannerButtonsActive = false;
					}*/

					RaiseOperationError(-1, ex);
				}
			}

			this.messagePumpLocker.Set();
		}
		#endregion

		#region Scan_Thread()
		private void Scan_Thread(int operationId, string scanSettings)
		{
			try
			{
				Thread.Sleep(100);
				string filePath = string.Format("{0}\\{1}.jpg", imageDir.FullName, DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss-ff"));
				scanner.Scan(filePath);

				ImageScanned(operationId, filePath);
			}
			catch (ScannersEx ex)
			{
				RaiseOperationError(operationId, ex);
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't scan image!" + " " + ex.Message, ex);
				RaiseOperationError(operationId, ex);
			}
		}
		#endregion

		#region RaiseOperationSuccessfull()
		/*protected void RaiseOperationSuccessfull(int operationId)
		{
			try
			{
				if (OperationSuccessfull != null)
					OperationSuccessfull(operationId);
			}
			catch { }
		}*/
		#endregion
	
		#region RaiseOperationError()
		protected void RaiseOperationError(int operationId, Exception ex)
		{
			try
			{
				if (OperationError != null)
					OperationError(operationId, ex);
			}
			catch { }
		}
		#endregion

		#region SetScanner()
		protected void SetScanner()
		{
			/*switch (this.paperSize)
			{
				case Scanners.ScanDocSize.DoubleLetter: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.X11x17Landscape; break;
				case Scanners.ScanDocSize.Legal: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LegalLandscape; break;
				case Scanners.ScanDocSize.Letter: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterLandscape; break;
				case Scanners.ScanDocSize.LetterLandscape: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterLandscape; break;
				case Scanners.ScanDocSize.LetterLeft: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterPortraitLeft; break;
				case Scanners.ScanDocSize.LetterRight: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.LetterPortraitRight; break;
				case Scanners.ScanDocSize.Max: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumLandscape; break;
				case Scanners.ScanDocSize.MaxLeft: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumPortraitLeft; break;
				case Scanners.ScanDocSize.MaxRight: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumPortraitRight; break;
				case Scanners.ScanDocSize.MaxBoth: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.MaximumLandscape; break;
				case Scanners.ScanDocSize.User: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.User; break;
				default: this.scanner.Settings.DocSize.Value = Scanners.S2N.DocumentSizeType.Auto; break;
			}*/

			this.scanner.Settings.Splitting.Value = this.splitting;

			if (this.ColorMode == Scanners.ColorMode.Bitonal)
				this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Lineart;
			else if (this.scanner.IsColorScanner && (this.ColorMode == Scanners.ColorMode.Color || this.ColorMode == Scanners.ColorMode.Unknown))
				this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Color;
			else 
				this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Grayscale;

			switch (this.FileFormat)
			{
				case Scanners.FileFormat.Png:
				case Scanners.FileFormat.Tiff:
					this.scanner.Settings.FileFormat.Value = FileFormatType.TIFF; break;
				default: this.scanner.Settings.FileFormat.Value = FileFormatType.JPEG; break; 
			}

			/*switch (this.colorMode)
			{
				case Scanners.ColorMode.Grayscale: this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Grayscale; break;
				case Scanners.ColorMode.Bitonal: this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Lineart; break;
				case Scanners.ColorMode.Photo: this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Photo; break;
				default: this.scanner.Settings.ColorMode.Value = Scanners.S2N.ColorModeType.Color; break;
			}*/

			this.scanner.Settings.Dpi.Value = GetDpi();// Math.Max(this.scanner.Settings.Dpi.Minimum, Math.Min(this.scanner.Settings.Dpi.Maximum, this.dpi));
			this.scanner.Settings.Brightness.Value = Math.Max(this.scanner.Settings.Brightness.Minimum, Math.Min(this.scanner.Settings.Brightness.Maximum, (int)(((this.brightness + 1) / 2) * 255.0)));
			this.scanner.Settings.Contrast.Value = Math.Max(this.scanner.Settings.Contrast.Minimum, Math.Min(this.scanner.Settings.Contrast.Maximum, (int)(((this.contrast + 1) / 2) * 255.0)));

			if (this.scanner.Settings.DocMode.IsDefined)
			{
				switch (this.cradlePosition)
				{
					case Scanners.CradlePosition.Flat: this.scanner.Settings.DocMode.Value = Scanners.S2N.DocumentModeType.Flat; break;
					case Scanners.CradlePosition.V: this.scanner.Settings.DocMode.Value = Scanners.S2N.DocumentModeType.V; break;
					default: this.scanner.Settings.DocMode.Value = Scanners.S2N.DocumentModeType.Auto; break;
				}
			}
		}
		#endregion

		#endregion

	}
}
