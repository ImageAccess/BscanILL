﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scanners.S2N
{

	#region enum AutofocusType
	public enum AutofocusType
	{
		On,
		Off,
		Skip
	}
	#endregion

	#region enum BitonalThresholdType
	public enum BitonalThresholdType
	{
		Dynamic,
		Fixed
	}
	#endregion

	#region enum ColorModeType
	public enum ColorModeType
	{
		Color,
		Grayscale,
		Lineart,
		Photo
	}
	#endregion

	#region enum DespeckleType
	public enum DespeckleType
	{
		Off,
		Despeckle4x4
	}
	#endregion

	#region enum DocumentModeType
	public enum DocumentModeType
	{
		Flat = 0,
		Book = 1,
		Folder = 2,
		FixedFocus = 3,
		GlassPlate = 4,
		Auto = 5,
		V = 6
	}
	#endregion

	#region enum DocumentSizeType
	public enum DocumentSizeType
	{
		MaximumLandscape,
		MaximumPortraitLeft,
		MaximumPortraitRight,
		LegalLandscape,
		LetterLandscape,
		LetterPortraitLeft,
		LetterPortraitRight,
		HalfLetterProtraitLeft,
		HalfLetterProtraitRight,
		X11x17Landscape,
		X11x17PortraitLeft,
		X11x17PortraitRight,
		User,
		Auto
	}
	#endregion

	#region enum DpiModeType
	public enum DpiModeType
	{
		Flexible,
		Fixed
	}
	#endregion

	#region enum FileFormatType
	public enum FileFormatType
	{
		JPEG,
		TIFF,
		PNM,
		PDF,
		Unknown
	}
	#endregion

	#region enum LightType
	public enum LightType
	{
		On,
		Off
	}
	#endregion

	#region enum RotationType
	public enum RotationType
	{
		None = 0,
		CV90 = 90,
		CV180 = 180,
		CV270 = 270
	}
	#endregion

	#region enum ScanModeType
	public enum ScanModeType
	{
		Direct,
		Wait
	}
	#endregion

	#region enum SpeedType
	public enum SpeedType
	{
		Quality,
		Fast
	}
	#endregion

	#region enum SplittingType
	public enum SplittingType
	{
		Off,
		Left,
		Right
	}
	#endregion

	#region enum TiffCompressionType
	public enum TiffCompressionType
	{
		None,
		G4
	}
	#endregion

	#region enum UserUnitType
	public enum UserUnitType
	{
		mm,
		mil
	}
	#endregion


}
