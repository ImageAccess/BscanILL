using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging ;
using System.Data;
using System.IO ;
using System.Net ;
using System.Text ;
using System.Diagnostics ;
using System.Configuration ;
using System.Timers;
using System.Net.Cache;
using System.Threading;



namespace Scanners.S2N
{
	public class Bookeye4 : ScannerBase
	{
		static Bookeye4		instance = null;
		public bool			scanWaitAlive = false;
		bool				isUiLocked = false;

		ScannerScanAreaSelection lastScanAreaSelection = ScannerScanAreaSelection.Flat;

		//touch screen monitoring
		System.Timers.Timer touchScreenMonitoringTimer = new System.Timers.Timer();
		volatile bool runScannerTouchScreenMonitoring = false;

		public delegate void ScanRequestHnd(Scanners.S2N.Bookeye4.ScannerScanAreaSelection scanArea);
		public event ScanRequestHnd			ScanRequest;


		#region constructor
		private Bookeye4()
		{	
			this.touchScreenMonitoringTimer.AutoReset = false;
			this.touchScreenMonitoringTimer.Interval = 500;
			this.touchScreenMonitoringTimer.Elapsed += new ElapsedEventHandler(TouchScreenMonitoring_Tick);
		}
		#endregion


		#region destructor
		~Bookeye4()
		{
			Dispose();
		}
		#endregion

		#region enum ScannerScanAreaSelection
		public enum ScannerScanAreaSelection
		{
			Left,
			Right,
			Both,
			Flat
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties

		public bool					IsTouchScreenMonitoringRunning { get { return this.runScannerTouchScreenMonitoring; } }

		#endregion


		//PUBLIC METHODS
		#region public  methods

		#region GetInstance()
		public static Bookeye4 GetInstance()
		{	
			if (Bookeye4.instance == null)
				Bookeye4.instance = new Bookeye4();

			return Bookeye4.instance;
		}
		#endregion

		#region Dispose()
		public void Dispose()
		{
			try
			{
				this.touchScreenMonitoringTimer.Stop();
				Logout();
			}
			catch { }
			finally
			{
			}
		}
		#endregion

		#region Scan()
		/// <summary>
		/// saves image into 'filePath' or throws exception
		/// </summary>
		/// <param name="filePath"></param>
		public void Scan(string filePath)
		{
			lock (threadLocker)
			{
				this.settings.ScanMode.Value = Scanners.S2N.ScanModeType.Direct;
				
				HttpWebRequest webRequest = null;
				string htmlBody;

				try
				{					
					if (ProgressChanged != null)
						ProgressChanged("Scanning...", 0);

					Login();
					SetDevice(this);

					Thread.Sleep(100);

					//scanning
					try
					{
						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/scan?" + this.SessionId);
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 30000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								htmlBody = streamReader.ReadToEnd();
							}
						}
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, Scan(): Exception while sending scan request. " + ex.Message, ex);
						throw new ScannersEx("There is not connection to the scanner!", ScannersEx.AlertType.Warning);
					}

					if (htmlBody.IndexOf("OK") < 0)
					{
						if (htmlBody.ToLower().Contains("error 7") || htmlBody.ToLower().Contains("no focus"))
						{
							throw new ScannersEx(htmlBody);
						}
						else if (htmlBody.ToLower().Contains("crop failed"))
						{
							throw new ScannersEx(htmlBody);
						}
						else
						{
							Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, Scan(): Invalid parameters returned while sending scan request. " + htmlBody, null);
							throw new ScannersEx("Invalid parameters returned while sending scan request!");
						}
					}

					if (PreviewScanned != null)
						DownloadPreview();

					//save image
					DownloadImage(filePath);
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, Scan(), Scanner exception while scanning: " + ex.Message, ex);
					throw new ScannersEx("BookEye exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
					timerPingDevice.Start();
					//Logout();
				}
			}
		}
		#endregion

		#region LockUi()
		public void LockUi()
		{
			if (this.isUiLocked == false)
			{
				lock (threadLocker)
				{
					HttpWebRequest webRequest = null;
					string htmlBody;

					try
					{
						if (ProgressChanged != null)
							ProgressChanged("Locking UI...", 0);

						Login();

						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/sendcmd?" + this.SessionId + "+AppGUI+GUI:ScreenLockedILL");
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 5000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								if (streamReader.Peek() >= 0)
								{
									htmlBody = streamReader.ReadToEnd();

									if (htmlBody.IndexOf("OK") < 0)
									{
										Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, LockUi():" + " " + Environment.NewLine + htmlBody + Environment.NewLine, null);
										throw new ScannersEx("Can't setup scanner!");
									}
									else
									{
										// everything is OK
										this.isUiLocked = true;
									}
								}
								else
								{
									Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't get scanner response!", null);
									throw new ScannersEx("Can't get scanner response!");
								}
							}
						}

						if (ProgressChanged != null)
							ProgressChanged("Locking UI...", 1);
					}
					catch (ScannersEx ex)
					{
						throw ex;
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, LockUi():" + " " + ex.Message, ex);
						throw new ScannersEx("BookEye exception while locking UI:" + " " + ex.Message, ScannersEx.AlertType.Error);
					}
					finally
					{
						timerPingDevice.Start();
						//Thread.Sleep(100);
						//Logout();
					}
				}
			}
		}
		#endregion

		#region UnlockUi()
		public void UnlockUi()
		{
			if (this.isUiLocked)
			{
				lock (threadLocker)
				{
					HttpWebRequest webRequest = null;
					string htmlBody;

					try
					{
						if (ProgressChanged != null)
							ProgressChanged("Unlocking UI...", 0);

						Login();

						webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/sendcmd?" + this.SessionId + "+AppGUI+GUI:ScreenUnlocked");
						webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
						webRequest.Timeout = 5000;

						using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
						{
							using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
							{
								if (streamReader.Peek() >= 0)
								{
									htmlBody = streamReader.ReadToEnd();

									if (htmlBody.IndexOf("OK") < 0)
									{
										Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, UnlockUi():" + Environment.NewLine + htmlBody + Environment.NewLine, null);
										throw new ScannersEx("Can't setup scanner!");
									}
									else
									{
										// everything is OK
										this.isUiLocked = false;
									}
								}
								else
								{
									Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't get scanner response!", null);
									throw new ScannersEx("Can't get scanner response!");
								}
							}
						}

						if (ProgressChanged != null)
							ProgressChanged("Unlocking UI...", 1);
					}
					catch (ScannersEx ex)
					{
						throw ex;
					}
					catch (Exception ex)
					{
						Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, UnlockUi(): " + ex.Message, ex);
						throw new ScannersEx("BookEye exception while unlocking UI:" + " " + ex.Message, ScannersEx.AlertType.Error);
					}
					finally
					{
						timerPingDevice.Start();
						//Thread.Sleep(100);
						//Logout();
					}
				}
			}
		}
		#endregion

		#region ScannerScanButtonPressed()
		public bool ScannerScanButtonPressed(ref ScannerScanAreaSelection scanAreaSelection)
		{
			lock (threadLocker)
			{
				try
				{
					Login();

					for (int i = 0; i <= exceptionIterations; i++)
					{
						try
						{
							HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/events?" + this.SessionId + "+poll");
							webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
							webRequest.Timeout = 5000;

							using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
							{
								using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
								{
									if (streamReader.Peek() >= 0)
									{
										string htmlBody = streamReader.ReadToEnd();

										if (htmlBody.IndexOf("OK") < 0 && htmlBody.IndexOf("ERROR 8") < 0)
										{
											if (htmlBody.Contains("Invalid"))
											{
												Login();
											}
											else
											{
												Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, ScannerScanButtonPressed(): " + Environment.NewLine + htmlBody + Environment.NewLine, null);
												throw new ScannersEx("Can't setup scanner!");
											}
										}
										else
										{
											string[] lines = htmlBody.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
											bool scanPressed = WasScanButtonPressed(lines, ref scanAreaSelection);
											this.lastScanAreaSelection = GetLastScannerScanAreaSelection(lines);

											return scanPressed;
										}
									}
									else
									{
										Notifications.Instance.Notify(this, Notifications.Type.Warning, "Can't get scanner response!", null);
										throw new ScannersEx("Can't get scanner response!");
									}
								}
							}
						}
						catch (ScannersEx ex)
						{
							throw ex;
						}
						catch (Exception ex)
						{
							if (ex.Message.ToLower().Contains("timed out") && i < exceptionIterations)
								Thread.Sleep(i * 100);
							else
							{
								Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, ScannerScanButtonPressed(): " + ex.Message, ex);
								throw new ScannersEx("BookEye exception while checking Bookeye4 UI buttons:" + " " + ex.Message, ScannersEx.AlertType.Error);
							}
						}
					}

					return false;
				}
				finally
				{
					timerPingDevice.Start();
					//Logout();
				}
			}
		}
		#endregion

		#region StartScannerTouchScreenMonitoring()
		public void StartScannerTouchScreenMonitoring()
		{
			this.runScannerTouchScreenMonitoring = true;
			this.touchScreenMonitoringTimer.Stop();
			this.touchScreenMonitoringTimer.Start();
		}
		#endregion

		#region StopScannerTouchScreenMonitoring()
		public void StopScannerTouchScreenMonitoring()
		{
			this.runScannerTouchScreenMonitoring = false;
			this.touchScreenMonitoringTimer.Stop();
		}
		#endregion

		#endregion


		//PRIVATE METHODS
		#region private methods
		
		#region SendCommandToScanner()
		protected override string SendCommandToScanner(Bookeye4.Command command, string parameters, int timeout)
		{
			string commandStr = (command == Command.Set) ? "set?" : "get?";

			try
			{
				Login();

				HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/" + commandStr + this.SessionId + parameters);
				webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
				webRequest.Timeout = timeout;

				using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
				{
					using (StreamReader reader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
					{
						if (reader.Peek() >= 0)
						{
							string response = reader.ReadToEnd();
							return response;
						}
						else
							throw new ScannersEx("Can't get scanner response!");
					}
				}
			}
			finally
			{
				timerPingDevice.Start();
			}
		}
		#endregion
	
		#region SetDevice()
		private void SetDevice(object sender)
		{
			lock (threadLocker)
			{
				try
				{
//#if !DEBUG
					//if (this.settings.SettingsChanged)
//#endif
					{
						if (this.settings.ColorMode.Value != ColorModeType.Lineart && this.settings.ColorMode.Value != ColorModeType.Photo)
							this.settings.TiffCompression.Value = TiffCompressionType.None;
						
						string settings = this.settings.ToString();

						if (settings.Length > 0)
						{
							//scanning
							string htmlBody = SendCommandToScanner(Command.Set, settings, 5000);

							if (htmlBody.IndexOf("OK") < 0)
							{
								Notifications.Instance.Notify(sender, Notifications.Type.Error, "Bookeye4 SetDevice('" + settings + "'): " + Environment.NewLine + htmlBody, null);
								throw new ScannersEx(string.Format("Error while setting scanner: {0}\n\n{1}", htmlBody, settings), ScannersEx.AlertType.Error);
							}

							this.settings.SettingsChanged = false;
						}
					}
				}
				catch (ScannersEx ex)
				{
					throw ex;
				}
				catch (Exception ex)
				{
					if (ex.Message.Contains("has timed out"))
						Notifications.Instance.Notify(sender, Notifications.Type.Warning, "Can't connect to the scanner!" + " "  + ex.Message, ex);
					else
						Notifications.Instance.Notify(sender, Notifications.Type.Error, "Bookeye4 SetDevice('" + settings + "'): " + ex.Message, ex);

					throw new ScannersEx("Scanner doesn't respond." + Environment.NewLine + ex.Message, ScannersEx.AlertType.Error);
				}
				finally
				{
				}
			}
		}
		#endregion

		#region WasScanButtonPressed()
		private bool WasScanButtonPressed(string[] lines, ref ScannerScanAreaSelection scanAreaSelection)
		{
			for (int i = lines.Length - 1; i >= 0; i--)
			{
				if (string.Compare(lines[i].Trim(), "scanner:ExternalScanRequest", true) == 0)
				{
					scanAreaSelection = ScannerScanAreaSelection.Flat;
					return true;
				}			
				else if (lines[i].Trim().ToLower() == "appgui:scanbutton" || lines[i].Trim().ToLower() == "appgui:footpedal")
				{
					for (int j = i - 1; j >= 0; j--)
					{
						string line = lines[j].Trim().ToLower();

						if (line == "appgui:topleftbutton")
						{
							scanAreaSelection = ScannerScanAreaSelection.Both;
							return true;
						}
						else if (line == "appgui:toprightbutton")
						{
							scanAreaSelection = ScannerScanAreaSelection.Flat;
							return true;
						}
						else if (line == "appgui:middleleftbutton")
						{
							scanAreaSelection = ScannerScanAreaSelection.Left;
							return true;
						}
						else if (line == "appgui:middlerightbutton")
						{
							scanAreaSelection = ScannerScanAreaSelection.Right;
							return true;
						}
					}

					scanAreaSelection = this.lastScanAreaSelection;
					return true;
				}
			}

			return false;
		}
		#endregion

		#region GetLastScannerScanAreaSelection()
		private ScannerScanAreaSelection GetLastScannerScanAreaSelection(string[] lines)
		{
			for (int i = lines.Length - 1; i >= 0; i--)
			{
				string line = lines[i].Trim().ToLower();

				if (line == "appgui:topleftbutton")
					return ScannerScanAreaSelection.Both;
				else if (line == "appgui:toprightbutton")
					return ScannerScanAreaSelection.Flat;
				else if (line == "appgui:middleleftbutton")
					return ScannerScanAreaSelection.Left;
				else if (line == "appgui:middlerightbutton")
					return ScannerScanAreaSelection.Right;
			}
					
			return this.lastScanAreaSelection;
		}
		#endregion

		#region DownloadImage()
		private void DownloadImage(string filePath)
		{
			try
			{
				HttpWebRequest webRequest = (HttpWebRequest)System.Net.WebRequest.Create(@"http://" + this.Ip + @"/cgi/image?" + this.SessionId);
				webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(RequestCacheLevel.NoCacheNoStore);
				webRequest.Timeout = 40000;

				using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
				{
					using (StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.ASCII))
					{

						if (webResponse.ContentType.ToLower().StartsWith("image") == false)
						{
							if (streamReader.Peek() >= 0)
								Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, Scan(): Web Response " + webResponse.ContentType + " " + streamReader.ReadToEnd(), null);
							else
								Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, Scan(): Web Response " + webResponse.ContentType, null);

							throw new ScannersEx("Can't get image!");
						}
						else
						{
							using (FileStream stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
							{
								int bufferSize = 0x20000;
								byte[] buffer = new byte[bufferSize];
								int bytesRead;

								while ((bytesRead = streamReader.BaseStream.Read(buffer, 0, bufferSize)) > 0)
								{
									stream.Write(buffer, 0, bytesRead);
								}
							}

							/*if (this.isColorScanner == false)
							{
								FileInfo fileInfo = new FileInfo(filePath);
								string tempPath = fileInfo.Directory.FullName + @"\" + Path.GetFileNameWithoutExtension(fileInfo.Name) + ".tmp";

								using (ImageProcessing.BigImages.ItDecoder itDecoder = new ImageProcessing.BigImages.ItDecoder(filePath))
								{
									resampling.Resample(itDecoder, tempPath, new ImageProcessing.FileFormat.Jpeg(80), ImageProcessing.PixelsFormat.Format24bppRgb);
								}

								fileInfo.Refresh();
								fileInfo.Delete();
								File.Move(tempPath, filePath);
							}*/
						}
					}
				}
			}
			catch (ScannersEx ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				Notifications.Instance.Notify(null, Notifications.Type.Error, "Bookeye4, DownloadImage(): " + ex.Message, ex);
				throw new ScannersEx("BookEye exception while scanning:" + " " + ex.Message, ScannersEx.AlertType.Error);
			}
		}
		#endregion

		#region TouchScreenMonitoring_Tick()
		void TouchScreenMonitoring_Tick(object sender, ElapsedEventArgs e)
		{
			lock (threadLocker)
			{
				try
				{
					this.touchScreenMonitoringTimer.Stop();
					Scanners.S2N.Bookeye4.ScannerScanAreaSelection selection = Scanners.S2N.Bookeye4.ScannerScanAreaSelection.Flat;
					bool scan = ScannerScanButtonPressed(ref selection);

					if (scan)
					{
						if (ScanRequest != null)
							ScanRequest(selection);
					}
				}
				catch (ScannersEx)
				{
					this.runScannerTouchScreenMonitoring = false;
					this.touchScreenMonitoringTimer.Stop();
				}
				catch (Exception ex)
				{
					this.runScannerTouchScreenMonitoring = false;
					this.touchScreenMonitoringTimer.Stop();

					Notifications.Instance.Notify(this, Notifications.Type.Error, "Bookeye4, TouchScreenMonitoring_Tick(): " + ex.Message, ex);
				}

				if (this.runScannerTouchScreenMonitoring)
					this.touchScreenMonitoringTimer.Start();
			}
		}
		#endregion

		#endregion

	}
}
