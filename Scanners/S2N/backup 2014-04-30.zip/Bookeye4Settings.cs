﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Scanners.S2N
{
	[Serializable]
	public class Bookeye4Settings
	{
		public readonly Scanners.S2N.S2NSettings.Autofocus Autofocus = new Scanners.S2N.S2NSettings.Autofocus();
		public readonly Scanners.S2N.S2NSettings.Range Gamma = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Speed Speed = new Scanners.S2N.S2NSettings.Speed();
		public readonly Scanners.S2N.S2NSettings.ScanMode ScanMode = new Scanners.S2N.S2NSettings.ScanMode();
		public readonly Scanners.S2N.S2NSettings.DocumentMode DocMode = new Scanners.S2N.S2NSettings.DocumentMode();
		public readonly Scanners.S2N.S2NSettings.ColorMode ColorMode = new Scanners.S2N.S2NSettings.ColorMode();
		public readonly Scanners.S2N.S2NSettings.Range Brightness = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range Contrast = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range Dpi = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.DpiMode DpiMode = new Scanners.S2N.S2NSettings.DpiMode();
		public readonly Scanners.S2N.S2NSettings.Light Light = new Scanners.S2N.S2NSettings.Light();
		public readonly Scanners.S2N.S2NSettings.Rotation Rotation = new S2NSettings.Rotation();
		public readonly Scanners.S2N.S2NSettings.Despeckle Despeckle = new S2NSettings.Despeckle();
		public readonly Scanners.S2N.S2NSettings.Range Sharpening = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range UserX = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range UserY = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range UserW = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.Range UserH = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.UserUnit UserUnit = new Scanners.S2N.S2NSettings.UserUnit();
		public readonly Scanners.S2N.S2NSettings.DocumentSize DocSize = new Scanners.S2N.S2NSettings.DocumentSize();
		public readonly Scanners.S2N.S2NSettings.Splitting Splitting = new Scanners.S2N.S2NSettings.Splitting();
		public readonly Scanners.S2N.S2NSettings.Range JpegQuality = new Scanners.S2N.S2NSettings.Range();
		public readonly Scanners.S2N.S2NSettings.TiffCompression TiffCompression = new Scanners.S2N.S2NSettings.TiffCompression();
		public readonly Scanners.S2N.S2NSettings.FileFormat FileFormat = new Scanners.S2N.S2NSettings.FileFormat();
		public readonly Scanners.S2N.S2NSettings.BitonalThreshold BitonalThreshold = new Scanners.S2N.S2NSettings.BitonalThreshold();

		List<Scanners.S2N.S2NSettings.ISetting> settingsList ;

		bool settingsChanged = false;


		#region constructor
		public Bookeye4Settings()
		{
		}

		public Bookeye4Settings(string settings)
		{
			this.settingsList = new List<Scanners.S2N.S2NSettings.ISetting>() {this.Autofocus, this.Gamma, this.Speed, this.ScanMode, 
				this.DocMode, this.ColorMode, this.Brightness, this.Contrast, this.Dpi, this.DpiMode, this.Rotation,
				this.Despeckle, this.Light, this.Sharpening, this.UserX, this.UserY, this.UserW, this.UserH, this.UserUnit, 
				this.DocSize, this.Splitting, this.JpegQuality, this.TiffCompression, this.FileFormat, this.BitonalThreshold};
	
			string[] settingsArray = settings.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
	
			foreach (string setting in settingsArray)
			{
				if (setting.StartsWith("autofocus:"))
					this.Autofocus.Load(setting);
				else if (setting.StartsWith("gamma:"))
					this.Gamma.Load(setting);
				else if (setting.StartsWith("speed:"))
					this.Speed.Load(setting);
				else if (setting.StartsWith("scanmode:"))
					this.ScanMode.Load(setting);
				else if (setting.StartsWith("docmode:"))
					this.DocMode.Load(setting);
				else if (setting.StartsWith("colormode:"))
					this.ColorMode.Load(setting);
				else if (setting.StartsWith("bright:"))
					this.Brightness.Load(setting);
				else if (setting.StartsWith("contr:"))
					this.Contrast.Load(setting);
				else if (setting.StartsWith("dpi:"))
					this.Dpi.Load(setting);
				else if (setting.StartsWith("dpi_mode:"))
					this.DpiMode.Load(setting);
				else if (setting.StartsWith("rotation:"))
					this.Rotation.Load(setting);
				else if (setting.StartsWith("despeckle:"))
					this.Despeckle.Load(setting);
				else if (setting.StartsWith("light:"))
					this.Light.Load(setting);
				else if (setting.StartsWith("sharpen:"))
					this.Sharpening.Load(setting);
				else if (setting.StartsWith("user_x:"))
					this.UserX.Load(setting);
				else if (setting.StartsWith("user_y:"))
					this.UserY.Load(setting);
				else if (setting.StartsWith("user_w:"))
					this.UserW.Load(setting);
				else if (setting.StartsWith("user_h:"))
					this.UserH.Load(setting);
				else if (setting.StartsWith("user_unit:"))
					this.UserUnit.Load(setting);
				else if (setting.StartsWith("docsize:"))
					this.DocSize.Load(setting);
				else if (setting.StartsWith("splitting:"))
					this.Splitting.Load(setting);
				else if (setting.StartsWith("jpeg_quality:"))
					this.JpegQuality.Load(setting);
				else if (setting.StartsWith("tiff_compr:"))
					this.TiffCompression.Load(setting);
				else if (setting.StartsWith("fileformat:"))
					this.FileFormat.Load(setting);
				else if (setting.StartsWith("dyn_bright:"))
					this.BitonalThreshold.Load(setting);
			}
	
			SetFromSettings();
	
			foreach (Scanners.S2N.S2NSettings.ISetting setting in settingsList)
				setting.Changed += delegate() { this.settingsChanged = true; };
		}
		#endregion


		//PUBLIC PROPERTIES
		#region public properties

		#region SettingsChanged
		public bool SettingsChanged
		{
			get { return this.settingsChanged; }
			set { this.settingsChanged = value; }
		}
		#endregion

		#endregion


		//PUBLIC METHODS
		#region public methods

		#region LoadFromSettings()
		/*internal void LoadFromSettings()
		{			
			Scanners.Settings.ScannerSettingsClass.Bookeye4Class s = Scanners.Settings.Instance.ScannerSettings.Bookeye4;
			
			if (this.Gamma.IsDefined)
				this.Gamma.Value = s.Gamma;
			if (this.Speed.IsDefined)
				this.Speed.Value = s.Speed;
			if (this.ScanMode.IsDefined)
				this.ScanMode.Value = s.ScanMode;
			if (this.DocMode.IsDefined)
				this.DocMode.Value = s.DocMode;
			if (this.ColorMode.IsDefined)
				this.ColorMode.Value = (s.ColorMode != ColorModeType.Color || this.ColorMode.IsColorOptionInstalled) ? s.ColorMode : ColorModeType.Grayscale;
			if (this.Brightness.IsDefined)
				this.Brightness.Value = s.Brightness;
			if (this.Contrast.IsDefined)
				this.Contrast.Value = s.Contrast;
			if (this.Dpi.IsDefined)
				this.Dpi.Value = s.Dpi;
			if (this.DpiMode.IsDefined)
				this.DpiMode.Value = s.DpiMode;
			if (this.Rotation.IsDefined)
				this.Rotation.Value = s.Rotation;
			if (this.Despeckle.IsDefined)
				this.Despeckle.Value = s.Despeckle;
			if (this.Sharpening.IsDefined)
				this.Sharpening.Value = s.Sharpening;
			if (this.UserX.IsDefined)
				this.UserX.Value = s.UserX;
			if (this.UserY.IsDefined)
				this.UserY.Value = s.UserY;
			if (this.UserW.IsDefined)
				this.UserW.Value = s.UserW;
			if (this.UserH.IsDefined)
				this.UserH.Value = s.UserH;
			if (this.UserUnit.IsDefined)
				this.UserUnit.Value = s.UserUnit;
			if (this.DocSize.IsDefined)
				this.DocSize.Value = s.DocSize;
			if (this.Splitting.IsDefined)
				this.Splitting.Value = s.Splitting;
			if (this.JpegQuality.IsDefined)
				this.JpegQuality.Value = s.JpegQuality;
			if (this.TiffCompression.IsDefined)
				this.TiffCompression.Value = s.TiffCompression;
			if (this.FileFormat.IsDefined)
				this.FileFormat.Value = s.FileFormat;
			if (this.BitonalThreshold.IsDefined)
				this.BitonalThreshold.Value = s.BitonalThreshold;
		}*/
		#endregion

		#region SaveToSettings()
		/*internal void SaveToSettings()
		{
			Scanners.Settings.ScannerSettingsClass.Bookeye4Class s = Scanners.Settings.Instance.ScannerSettings.Bookeye4;

			s.Gamma = this.Gamma.Value;
			s.Speed = this.Speed.Value;
			s.ScanMode = this.ScanMode.Value;
			s.DocMode = this.DocMode.Value;
			s.ColorMode = this.ColorMode.Value;
			s.Brightness = this.Brightness.Value;
			s.Contrast = this.Contrast.Value;
			s.Dpi = this.Dpi.Value;
			s.DpiMode = this.DpiMode.Value;
			s.Rotation = this.Rotation.Value;
			s.Despeckle = this.Despeckle.Value;
			s.Sharpening = this.Sharpening.Value;
			s.UserX = this.UserX.Value;
			s.UserY = this.UserY.Value;
			s.UserW = this.UserW.Value;
			s.UserH = this.UserH.Value;
			s.UserUnit = this.UserUnit.Value;
			s.DocSize = this.DocSize.Value;
			s.Splitting = this.Splitting.Value;
			s.JpegQuality = this.JpegQuality.Value;
			s.TiffCompression = this.TiffCompression.Value;
			s.FileFormat = this.FileFormat.Value;
			s.BitonalThreshold = this.BitonalThreshold.Value;
		}*/
		#endregion

		#region SetFromSettings()
		internal void SetFromSettings()
		{
			Scanners.SETTINGS.CurrentSettings currentSettings = Scanners.SETTINGS.CurrentSettings.Instance;

			if (this.Gamma.IsDefined)
				this.Gamma.Value = currentSettings.S2N.Gamma;

			if (this.Speed.IsDefined)
				this.Speed.Value = currentSettings.S2N.Speed;

			if (this.ScanMode.IsDefined)
				this.ScanMode.Value = currentSettings.S2N.ScanMode;

			if (this.DocMode.IsDefined)
				this.DocMode.Value = currentSettings.S2N.DocMode;

			if (this.ColorMode.IsDefined)
			{
				if (this.ColorMode.IsColorOptionInstalled == false && (currentSettings.S2N.ColorMode == ColorModeType.Color))
					this.ColorMode.Value = Scanners.S2N.ColorModeType.Grayscale;
				else
					this.ColorMode.Value = currentSettings.S2N.ColorMode;
			}

			if (this.Brightness.IsDefined)
				this.Brightness.Value = Convert.ToInt32(((currentSettings.S2N.Brightness + 1.0) / 2.0) * 255.0);

			if (this.Contrast.IsDefined)
				this.Contrast.Value = Convert.ToInt32(((currentSettings.S2N.Contrast + 1.0) / 2.0) * 255.0);

			if (this.Dpi.IsDefined)
				this.Dpi.Value = currentSettings.S2N.Dpi;

			if (this.DpiMode.IsDefined)
				this.DpiMode.Value = currentSettings.S2N.DpiMode;

			if (this.Rotation.IsDefined)
				this.Rotation.Value = currentSettings.S2N.Rotation;

			if (this.Despeckle.IsDefined)
				this.Despeckle.Value = currentSettings.S2N.Despeckle;

			if (this.Sharpening.IsDefined)
				this.Sharpening.Value = currentSettings.S2N.Sharpening;

			if (this.UserX.IsDefined)
				this.UserX.Value = currentSettings.S2N.UserX;

			if (this.UserY.IsDefined)
				this.UserY.Value = currentSettings.S2N.UserY;
			if (this.UserW.IsDefined)
				this.UserW.Value = currentSettings.S2N.UserW;
			if (this.UserH.IsDefined)
				this.UserH.Value = currentSettings.S2N.UserH;
			if (this.UserUnit.IsDefined)
				this.UserUnit.Value = currentSettings.S2N.UserUnit;
			if (this.DocSize.IsDefined)
				this.DocSize.Value = currentSettings.S2N.DocSize;
			if (this.Splitting.IsDefined)
				this.Splitting.Value = currentSettings.S2N.Splitting;

			if (this.JpegQuality.IsDefined)
				this.JpegQuality.Value = currentSettings.S2N.JpegQuality;
			if (this.TiffCompression.IsDefined)
				this.TiffCompression.Value = currentSettings.S2N.TiffCompression;
			if (this.FileFormat.IsDefined)
				this.FileFormat.Value =currentSettings.S2N.FileFormat;
			if (this.BitonalThreshold.IsDefined)
				this.BitonalThreshold.Value = currentSettings.S2N.BitonalThreshold;
		}
		#endregion

		#region ToString()
		public override string ToString()
		{
			string settings = "";

			foreach (Scanners.S2N.S2NSettings.ISetting setting in settingsList)
				if (setting.IsDefined)
					settings += setting.ToString();

			return settings;
		}
		#endregion

		#endregion

	}
}
