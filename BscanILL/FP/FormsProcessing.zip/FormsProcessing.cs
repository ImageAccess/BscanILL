﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BscanILL.FormsProcessing
{
	/*class FormsProcessing
	{

		public static void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (CurrentBscanObject == null)
				{
					CurrentBscanObject = new BscanWrapper();
				}

				CurrentBscanObject.InitModule(BscanWrapper.EngineType.SCRIPT | BscanWrapper.EngineType.BARCODE | BscanWrapper.EngineType.TOCR);

				// application path property needs to be set just becasue string is needed for pull slip training.
				// for now, please keep the training's files in the same location as current trainings: C:\Bscanill\Lib\'training name'
				// until we will test that all works fine when different location is used...
				CurrentBscanObject.ApplicationPath = "C:\\BscanILL\\Apps\\ILLScan.bsa";

				// current training name
				CurrentBscanObject.TrainingName = "ND-SHOW";

				if (CurrentBscanObject.LoadImage(-1, 0, @"C:\BSCANILL\Lib\ND-SHOW\ND-SHOW-Master-FormA.TIF") >= 0)
				{
					// path to current training , 21 is process number to be executed in the bsa file. we use always 21 for trainings...
					CurrentBscanObject.ExecuteScript(@"C:\BSCANILL\Lib\ND-SHOW\ND-SHOW.bsa", 21);
					string illNumber = CurrentBscanObject.ILL;
					string tnNumber = CurrentBscanObject.TN;
					string arielAddress = CurrentBscanObject.Address;
					string patronName = CurrentBscanObject.Patron;
					string deliveryMethod = CurrentBscanObject.Delivery;

				}



			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Exception:", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}*/
}
